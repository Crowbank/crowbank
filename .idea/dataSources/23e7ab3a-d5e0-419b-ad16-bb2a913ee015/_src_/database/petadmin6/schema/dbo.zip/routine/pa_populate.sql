-- DEBUG
-- Remove procedure CREATE ... END including parameters
-- Uncomment declare and select lines and make sure dbpath is correct
-- Paste into query

-- Redundant tables:
-- tblbillrate
-- tblexclusion
-- tblgroomer
-- tblgroomslot
-- tblrunrate
-- tblrunview
-- tblsmshistory
-- tbltask
-- tblweightrate


CREATE PROCEDURE [dbo].[pa_populate] 
	@conn nvarchar(255),
	@dbpath nvarchar(255)
AS
BEGIN

--declare @conn nvarchar(255)
--declare @dbpath nvarchar(255)
--select @conn='Microsoft.ACE.OLEDB.12.0'
--select @dbpath='c:\petadminplus\temp\tempdata.mdb'

	declare @sql nvarchar(max)
	declare @err int

	-- Can't do this inside begin trans
	-- exec sp_configure 'show advanced options', 1
	-- RECONFIGURE
	-- exec sp_configure 'Ad Hoc Distributed Queries', 1
	-- RECONFIGURE

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

print 'tbladdressbook'
	-----------------------------------------------------
	delete from tbladdressbook 
	set identity_insert tbladdressbook  on
	select @sql = 'insert into tbladdressbook  ' +
		'([abk_no] ' +
      ',[abk_company_name] ' +
      ',[abk_surname] ' +
      ',[abk_forename] ' +
      ',[abk_addr1] ' +
      ',[abk_addr2] ' +
      ',[abk_addr3] ' +
      ',[abk_postcode] ' +
      ',[abk_telno_1] ' +
      ',[abk_telno_2] ' +
      ',[abk_telno_mobile] ' +
      ',[abk_fax_no] ' +
      ',[abk_email] ' +
      ',[abk_category] ' +
      ',[abk_notes] ' +
      ',[abk_addr2a] ' +
      ',[abk_addr2b] ' +
      ',[abk_title] ' +
      ',[abk_website] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + @dbpath + ''')...tbladdressbook '
	exec sp_executesql @sql
	set identity_insert tbladdressbook  off
print 'tblaudit'
	-----------------------------------------------------
	delete from tblaudit 
	set identity_insert tblaudit on
	select @sql = 'insert into tblaudit ' +
		'([aud_no] ' +
      ',[aud_init] ' +
      ',[aud_key] ' +
      ',[aud_type] ' +
      ',[aud_action] ' +
      ',[aud_date] ' +
      ',[aud_time] ' +
      ',[aud_cust_no] ' +
      ',[aud_cust_surname] ' +
      ',[aud_bk_start_date] ' +
      ',[aud_bk_end_date] ' +
      ',[aud_amount] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblaudit'
	exec sp_executesql @sql
	set identity_insert tblaudit off
print 'tblauspostcode'
	-----------------------------------------------------
	delete from tblauspostcode
	--set identity_insert tblauspostcode on
	select @sql = 'insert into tblauspostcode ' +
		'([aus_postcode] ' +
      ',[aus_locality] ' +
      ',[aus_state] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblauspostcode'
	exec sp_executesql @sql
	--set identity_insert tblauspostcode off
print 'tblbillcategory'
	-----------------------------------------------------
	delete from tblbillcategory
	set identity_insert tblbillcategory on
	select @sql = 'insert into tblbillcategory ' +
		'([billcat_no] ' +
      ',[billcat_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblbillcategory'
	exec sp_executesql @sql
	set identity_insert tblbillcategory off
print 'tblbooking'
	-----------------------------------------------------
	delete from tblbooking
	set identity_insert tblbooking on
	select @sql = 'insert into tblbooking ' +
		'([bk_no] ' +
      ',[bk_cust_no] ' +
      ',[bk_start_date] ' +
      ',[bk_end_date] ' +
      ',[bk_start_time] ' +
      ',[bk_end_time] ' +
      ',[bk_gross_amt] ' +
      ',[bk_paid_amt] ' +
      ',[bk_vat_amt] ' +
      ',[bk_net_amt] ' +
      ',[bk_vat_percentage] ' +
      ',[bk_amt_outstanding] ' +
      ',[bk_extra_net_amt] ' +
      ',[bk_disc_value] ' +
      ',[bk_disc_type] ' +
      ',[bk_disc_total] ' +
      ',[bk_paytype] ' +
      ',[bk_payref] ' +
      ',[bk_notes] ' +
      ',[bk_extra_vat_amt] ' +
      ',[bk_inv_date] ' +
      ',[bk_disc_vat] ' +
      ',[bk_inv_no] ' +
      ',[bk_vat2_amt] ' +
      ',[bk_extra_vat2_amt] ' +
      ',[bk_disc_vat2] ' +
      ',[bk_exported] ' +
      ',[bk_status] ' +
      ',[bk_create_date] ' +
      ',[bk_memo] ' +
      ',[bk_print_ack] ' +
      ',[bk_print_conf] ' +
      ',[bk_print_contract] ' +
      ',[bk_print_inv] ' +
      ',[bk_memo_flag_in] ' +
      ',[bk_memo_flag_out] ' +
      ',[bk_archive] ' +
      ',[bk_rate_seq] ' +
      ',[bk_pickup_no] ' +
      ',[bk_dropoff_no] ' +
      ',[bk_type] ' +
      ',[bk_tr_no] ' +
      ',[bk_ti_no] ' +
      ',[bk_club_no] ' +
      ',[bk_ev_no] ' +
      ',[bk_ev_places] ' +
      ',[bk_new] ' +
      ',[bk_recur] ' +
      ',[bk_diary_count] ' +
      ',[bk_run_lock] ' +
      ',[bk_pickup_status] ' +
      ',[bk_dropoff_status] ' +
      ',[bk_alloc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblbooking'
	exec sp_executesql @sql
	set identity_insert tblbooking off
print 'tblbookingcomments'
	-----------------------------------------------------
	delete from tblbookingcomments
	--set identity_insert tblbookingcomments on
	select @sql = 'insert into tblbookingcomments ' +
		'([bkcomm_bk_no] ' +
      ',[bkcomm_pet_no] ' +
      ',[bkcomm_flagin] ' +
      ',[bkcomm_flagout] ' +
      ',[bkcomm_date] ' +
      ',[bkcomm_text] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblbookingcomments'
	exec sp_executesql @sql
	--set identity_insert tblbookingcomments off
print 'tblbkrun'
	-----------------------------------------------------
	delete from tblbkrun
	--set identity_insert tblbkrun on
	select @sql = 'insert into tblbkrun ' +
		'([br_bk_no] ' +
      ',[br_spec_no] ' +
      ',[br_count] ' +
      ',[br_ignore] ' +
      ',[br_date] ' +
      ',[br_rt_no] ' +
      ',[br_rs_no] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblbkrun'
	exec sp_executesql @sql
	--set identity_insert tblbkrun off
print 'tblbookingitem'
	-----------------------------------------------------
	delete from tblbookingitem
	--set identity_insert tblbookingitem on
	select @sql = 'insert into tblbookingitem ' +
		'([bi_bk_no] ' +
      ',[bi_pet_no] ' +
      ',[bi_checkin_date] ' +
      ',[bi_checkin_time] ' +
      ',[bi_est_checkin_time] ' +
      ',[bi_checkout_date] ' +
      ',[bi_checkout_time] ' +
      ',[bi_est_checkout_time] ' +
      ',[bi_medication] ' +
      ',[bi_groom] ' +
      ',[bi_groom_date] ' +
      ',[bi_in_season] ' +
      ',[bi_init_in] ' +
      ',[bi_init_out] ' +
      ',[bi_heating] ' +
      ',[bi_rs_no] ' +
      ',[bi_comments] ' +
      ',[bi_pickup_date] ' +
      ',[bi_pickup_time] ' +
      ',[bi_dropoff_date] ' +
      ',[bi_dropoff_time] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblbookingitem'
	exec sp_executesql @sql
	--set identity_insert tblbookingitem off
print 'tblbreed'
	-----------------------------------------------------
	delete from tblbreed
	set identity_insert tblbreed on
	select @sql = 'insert into tblbreed ' +
		'([breed_no] ' +
      ',[breed_spec_no] ' +
      ',[breed_desc] ' +
      ',[breed_billcat_no] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblbreed'
	exec sp_executesql @sql
	set identity_insert tblbreed off
print 'tblcheckin'
	-----------------------------------------------------
	delete from tblcheckin
	--set identity_insert tblcheckin on
	select @sql = 'insert into tblcheckin ' +
		'([ci_bk_no] ' +
      ',[ci_pet_no] ' +
      ',[ci_date] ' +
      ',[ci_time] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcheckin'
	exec sp_executesql @sql
	--set identity_insert tblcheckin off
print 'tblcheckout'
	-----------------------------------------------------
	delete from tblcheckout
	--set identity_insert tblcheckout on
	select @sql = 'insert into tblcheckout ' +
		'([co_bk_no] ' +
      ',[co_pet_no] ' +
      ',[co_date] ' +
      ',[co_time] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcheckout'
	exec sp_executesql @sql
	--set identity_insert tblcheckout off
print 'tblclub'
	-----------------------------------------------------
	delete from tblclub
	set identity_insert tblclub on
	select @sql = 'insert into tblclub ' +
		'([club_no] ' +
      ',[club_name] ' +
      ',[club_places] ' +
      ',[club_day] ' +
      ',[club_time] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblclub'
	exec sp_executesql @sql
	set identity_insert tblclub off
print 'tblclubday'
	-----------------------------------------------------
	delete from tblclubday
	set identity_insert tblclubday on
	select @sql = 'insert into tblclubday ' +
		'([cd_no] ' +
      ',[cd_bk_no] ' +
      ',[cd_date] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblclubday'
	exec sp_executesql @sql
	set identity_insert tblclubday off
print 'tblcollar'
	-----------------------------------------------------
	delete from tblcollar
	set identity_insert tblcollar on
	select @sql = 'insert into tblcollar ' +
		'([collar_no] ' +
      ',[collar_desc] ' +
      ',[collar_default] ' +
      ',[collar_type] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcollar'
	exec sp_executesql @sql
	set identity_insert tblcollar off
print 'tblcollarfields'
	-----------------------------------------------------
	delete from tblcollarfields
	set identity_insert tblcollarfields on
	select @sql = 'insert into tblcollarfields ' +
		'([cf_no] ' +
      ',[cf_collar_no] ' +
      ',[cf_desc] ' +
      ',[cf_position] ' +
      ',[cf_fontsize] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcollarfields'
	exec sp_executesql @sql
	set identity_insert tblcollarfields off
print 'tblcolour'
	-----------------------------------------------------
	delete from tblcolour
	set identity_insert tblcolour on
	select @sql = 'insert into tblcolour ' +
		'([col_no] ' +
      ',[col_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcolour'
	exec sp_executesql @sql
	set identity_insert tblcolour off
print 'tblcomments'
	-----------------------------------------------------
	delete from tblcomments
	set identity_insert tblcomments on
	select @sql = 'insert into tblcomments ' +
		'([comm_no] ' +
      ',[comm_code] ' +
      ',[comm_text] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcomments'
	exec sp_executesql @sql
	set identity_insert tblcomments off
print 'tblcustdocument'
	-----------------------------------------------------
	delete from tblcustdocument
	select @sql = 'insert into tblcustdocument ' +
		'([cd_cust_no] ' +
      ',[cd_desc] ' +
      ',[cd_path] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcustdocument'
	exec sp_executesql @sql
print 'tblcustom'
	-----------------------------------------------------
	delete from tblcustom
	set identity_insert tblcustom on
	select @sql = 'insert into tblcustom ' +
		'([custom_no] ' +
      ',[custom_code] ' +
      ',[custom_name] ' +
      ',[custom_locations1] ' +
      ',[custom_locations2] ' +
      ',[custom_email_no] ' +
      ',[custom_data] ' +
      ',[custom_triggers] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcustom'
	exec sp_executesql @sql
	set identity_insert tblcustom off
print 'tblcustomer'
	-----------------------------------------------------
	delete from tblcustomer
	set identity_insert tblcustomer on
	select @sql = 'insert into tblcustomer ' +
		'([cust_no] ' +
      ',[cust_surname] ' +
      ',[cust_forename] ' +
      ',[cust_company_name] ' +
      ',[cust_addr1] ' +
      ',[cust_addr2] ' +
      ',[cust_addr3] ' +
      ',[cust_postcode] ' +
      ',[cust_telno_home] ' +
      ',[cust_telno_work] ' +
      ',[cust_email] ' +
      ',[cust_warning] ' +
      ',[cust_contact_name] ' +
      ',[cust_contact_telno] ' +
      ',[cust_notes] ' +
      ',[cust_ref] ' +
      ',[cust_discount] ' +
      ',[cust_telno_mobile] ' +
      ',[cust_contact2_name] ' +
      ',[cust_contact2_telno] ' +
      ',[cust_addr2a] ' +
      ',[cust_addr2b] ' +
      ',[cust_title] ' +
      ',[cust_status] ' +
      ',[cust_nopromotion] ' +
      ',[cust_create_date] ' +
      ',[cust_src_no] ' +
      ',[cust_pickup_no] ' +
      ',[cust_tour_date] ' +
      ',[cust_tour_userno] ' +
      ',[cust_recommend_no] ' +
      ',[cust_telno_mobile2] ' +
      ',[cust_custom1] ' +
      ',[cust_custom2] ' +
      ',[cust_custom3] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblcustomer'
	exec sp_executesql @sql
	set identity_insert tblcustomer off
print 'tbldiary'
	-----------------------------------------------------
	delete from tbldiary
	set identity_insert tbldiary on
	select @sql = 'insert into tbldiary ' +
		'([d_no] ' +
      ',[d_bk_no] ' +
      ',[d_pet_no] ' +
      ',[d_start_time] ' +
      ',[d_end_time] ' +
      ',[d_date] ' +
      ',[d_resource_no] ' +
      ',[d_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbldiary'
	exec sp_executesql @sql
	set identity_insert tbldiary off
print 'tbldiscount'
	-----------------------------------------------------
	delete from tbldiscount
	--set identity_insert tbldiscount on
	select @sql = 'insert into tbldiscount ' +
		'([disc_bk_no] ' +
      ',[disc_srv_no] ' +
      ',[disc_peak] ' +
      ',[disc_pet_no] ' +
      ',[disc_value] ' +
      ',[disc_vat_percentage] ' +
      ',[disc_vat2_percentage] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbldiscount'
	exec sp_executesql @sql
	--set identity_insert tbldiscount off
print 'tblemail'
	-----------------------------------------------------
	delete from tblemail
	set identity_insert tblemail on
	select @sql = 'insert into tblemail ' +
		'([email_no] ' +
      ',[email_subject] ' +
      ',[email_body] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblemail'
	exec sp_executesql @sql
	set identity_insert tblemail off
print 'tblemailtemplate'
	-----------------------------------------------------
	delete from tblemailtemplate
	set identity_insert tblemailtemplate on
	select @sql = 'insert into tblemailtemplate ' +
		'([et_no] ' +
      ',[et_name] ' +
      ',[et_desc] ' +
      ',[et_mail_no] ' +
      ',[et_locations] ' +
      ',[et_triggers] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblemailtemplate'
	exec sp_executesql @sql
	set identity_insert tblemail off
print 'tblevent'
	-----------------------------------------------------
	delete from tblevent
	set identity_insert tblevent on
	select @sql = 'insert into tblevent ' +
		'([ev_no] ' +
      ',[ev_name] ' +
      ',[ev_date] ' +
      ',[ev_time] ' +
      ',[ev_places] ' +
      ',[ev_taken] ' +
      ',[ev_rate] ' +
      ',[ev_loc_no] ' +
      ',[ev_vat_percentage] ' +
		') ' +
		'select [ev_no] ' +
      ',[ev_name] ' +
      ',[ev_date] ' +
      ',[ev_time] ' +
      ',[ev_places] ' +
      ',[ev_taken] ' +
      ',[ev_rate] ' +
      ',[ev_loc_no] ' +
      ',[ev_vat_percentage] from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblevent'
	exec sp_executesql @sql
	set identity_insert tblevent off
print 'tblextra'
	-----------------------------------------------------
	delete from tblextra
	set identity_insert tblextra on
	select @sql = 'insert into tblextra ' +
		'([ex_no] ' +
      ',[ex_desc] ' +
      ',[ex_net_amt] ' +
      ',[ex_vat_percentage] ' +
      ',[ex_vat2_percentage] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblextra'
	exec sp_executesql @sql
	set identity_insert tblextra off
print 'tblfeed'
	-----------------------------------------------------
	delete from tblfeed
	set identity_insert tblfeed on
	select @sql = 'insert into tblfeed ' +
		'([fd_no] ' +
      ',[fd_feedtype] ' +
      ',[fd_spec_no] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblfeed'
	exec sp_executesql @sql
	set identity_insert tblfeed off
print 'tblhistory'
	-----------------------------------------------------
	delete from tblhistory
	set identity_insert tblhistory on
	select @sql = 'insert into tblhistory ' +
		'([hist_no] ' +
      ',[hist_cust_no] ' +
      ',[hist_bk_no] ' +
      ',[hist_date] ' +
      ',[hist_user] ' +
      ',[hist_type] ' +
      ',[hist_report] ' +
      ',[hist_destination] ' +
      ',[hist_subject] ' +
      ',[hist_msg] ' +
      ',[hist_attachments] ' +
      ',[hist_pet_no] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblhistory'
	exec sp_executesql @sql
	set identity_insert tblhistory off
print 'tblholiday'
	-----------------------------------------------------
	delete from tblholiday
	--set identity_insert tblholiday on
	select @sql = 'insert into tblholiday ' +
		'([h_date] ' +
      ',[h_state] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblholiday'
	exec sp_executesql @sql
	--set identity_insert tblholiday off
print 'tblinnoculation'
	-----------------------------------------------------
	delete from tblinnoculation
	set identity_insert tblinnoculation on
	select @sql = 'insert into tblinnoculation ' +
		'([inn_no] ' +
      ',[inn_desc] ' +
      ',[inn_duration_months] ' +
      ',[inn_spec_no] ' +
      ',[inn_mandatory] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblinnoculation'
	exec sp_executesql @sql
	set identity_insert tblinnoculation off
print 'tblinvextra'
	-----------------------------------------------------
	delete from tblinvextra
	set identity_insert tblinvextra on
	select @sql = 'insert into tblinvextra ' +
		'([ie_no] ' +
      ',[ie_bk_no] ' +
      ',[ie_desc] ' +
      ',[ie_unit_price] ' +
      ',[ie_quantity] ' +
      ',[ie_total] ' +
      ',[ie_vat_percentage] ' +
      ',[ie_vat2_percentage] ' +
      ',[ie_status] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblinvextra'
	exec sp_executesql @sql
	set identity_insert tblinvextra off
print 'tblinvitem'
	-----------------------------------------------------
	delete from tblinvitem
	--set identity_insert tblinvitem on
	select @sql = 'insert into tblinvitem ' +
		'([ii_bk_no] ' +
      ',[ii_pet_no] ' +
      ',[ii_srv_no] ' +
      ',[ii_quantity] ' +
      ',[ii_rate] ' +
      ',[ii_net_amt] ' +
      ',[ii_vat_percentage] ' +
      ',[ii_vat2_percentage] ' +
      ',[ii_peak] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblinvitem'
	exec sp_executesql @sql
	--set identity_insert tblinvitem off
print 'tbllabelsheet'
	-----------------------------------------------------
	delete from tbllabelsheet
	set identity_insert tbllabelsheet on
	select @sql = 'insert into tbllabelsheet ' +
		'([ls_no] ' +
      ',[ls_name] ' +
      ',[ls_height] ' +
      ',[ls_width] ' +
      ',[ls_vertical] ' +
      ',[ls_horizontal] ' +
      ',[ls_top_margin] ' +
      ',[ls_left_margin] ' +
      ',[ls_top_indent] ' +
      ',[ls_left_indent] ' +
      ',[ls_paper_kind] ' +
      ',[ls_orientation] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbllabelsheet'
	exec sp_executesql @sql
	set identity_insert tbllabelsheet off
print 'tbllocation'
	-----------------------------------------------------
	delete from tbllocation
	set identity_insert tbllocation on
	select @sql = 'insert into tbllocation ' +
		'([loc_no] ' +
      ',[loc_name] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbllocation'
	exec sp_executesql @sql
	set identity_insert tbllocation off
print 'tblmsword'
	-----------------------------------------------------
	delete from tblmsword
	set identity_insert tblmsword on
	select @sql = 'insert into tblmsword ' +
		'([msw_no] ' +
      ',[msw_name] ' +
      ',[msw_desc] ' +
      ',[msw_query] ' +
      ',[msw_copies] ' +
      ',[msw_action] ' +
      ',[msw_path] ' +
      ',[msw_locations] ' +
      ',[msw_email_no] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblmsword'
	exec sp_executesql @sql
	set identity_insert tblmsword off
print 'tblpayment'
	-----------------------------------------------------
	delete from tblpayment
	set identity_insert tblpayment on
	select @sql = 'insert into tblpayment ' +
		'([pay_no] ' +
      ',[pay_bk_no] ' +
      ',[pay_cust_no] ' +
      ',[pay_date] ' +
      ',[pay_amount] ' +
      ',[pay_type] ' +
      ',[pay_ref] ' +
      ',[pay_surcharge] ' +
      ',[pay_total] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpayment'
	exec sp_executesql @sql
	set identity_insert tblpayment off
print 'tblpaymentref'
	-----------------------------------------------------
	delete from tblpaymentref
	set identity_insert tblpaymentref on
	select @sql = 'insert into tblpaymentref ' +
		'([pr_no] ' +
      ',[pr_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpaymentref'
	exec sp_executesql @sql
	set identity_insert tblpaymentref off
print 'tblpet'
	-----------------------------------------------------
	delete from tblpet
	set identity_insert tblpet on
	select @sql = 'insert into tblpet ' +
		'([pet_no] ' +
      ',[pet_cust_no] ' +
      ',[pet_name] ' +
      ',[pet_spec_no] ' +
      ',[pet_breed_no] ' +
      ',[pet_petcolour] ' +
      ',[pet_dob] ' +
      ',[pet_warning] ' +
      ',[pet_sex] ' +
      ',[pet_in_season] ' +
      ',[pet_neutered] ' +
      ',[pet_isolate] ' +
      ',[pet_vet_no] ' +
      ',[pet_pins_no] ' +
      ',[pet_policy_ref] ' +
      ',[pet_inventory] ' +
      ',[pet_deceased] ' +
      ',[pet_notes] ' +
      ',[pet_feedtype] ' +
      ',[pet_feed_am] ' +
      ',[pet_feed_pm] ' +
      ',[pet_feed_noon] ' +
      ',[pet_feed_night] ' +
      ',[pet_feed_notes] ' +
      ',[pet_medic_am] ' +
      ',[pet_medic_pm] ' +
      ',[pet_medic_noon] ' +
      ',[pet_medic_night] ' +
      ',[pet_medic_notes] ' +
      ',[pet_groom_notes] ' +
      ',[pet_image_file] ' +
      ',[pet_groom_frequency] ' +
      ',[pet_weight] ' +
      ',[pet_medic_longterm] ' +
      ',[pet_microchip] ' +
      ',[pet_collar_size] ' +
      ',[pet_score] ' +
      ',[pet_score_desc] ' +
      ',[pet_groomer] ' +
      ',[pet_feedtype2] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpet'
	exec sp_executesql @sql
	set identity_insert tblpet off
print 'tblpetdocument'
	-----------------------------------------------------
	delete from tblpetdocument
	select @sql = 'insert into tblpetdocument ' +
		'([pd_pet_no] ' +
      ',[pd_desc] ' +
      ',[pd_path] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpetdocument'
	exec sp_executesql @sql
print 'tblpetinnoculation'
	-----------------------------------------------------
	delete from tblpetinnoculation
	set identity_insert tblpetinnoculation on
	select @sql = 'insert into tblpetinnoculation ' +
		'([pi_no] ' +
      ',[pi_pet_no] ' +
      ',[pi_inn_no] ' +
      ',[pi_innoculation_date] ' +
      ',[pi_cert_ref] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpetinnoculation'
	exec sp_executesql @sql
	set identity_insert tblpetinnoculation off
print 'tblpetinsurer'
	-----------------------------------------------------
	delete from tblpetinsurer
	set identity_insert tblpetinsurer on
	select @sql = 'insert into tblpetinsurer ' +
		'([pins_no] ' +
      ',[pins_name] ' +
      ',[pins_addr1] ' +
      ',[pins_addr2] ' +
      ',[pins_addr3] ' +
      ',[pins_postcode] ' +
      ',[pins_telno_1] ' +
      ',[pins_telno_2] ' +
      ',[pins_faxno] ' +
      ',[pins_notes] ' +
      ',[pins_addr2a] ' +
      ',[pins_addr2b] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpetinsurer'
	exec sp_executesql @sql
	set identity_insert tblpetinsurer off
print 'tblpetmedic'
	-----------------------------------------------------
	delete from tblpetmedic
	set identity_insert tblpetmedic on
	select @sql = 'insert into tblpetmedic ' +
		'([pm_no] ' +
      ',[pm_pet_no] ' +
      ',[pm_medic_am] ' +
      ',[pm_medic_noon] ' +
      ',[pm_medic_pm] ' +
      ',[pm_medic_night] ' +
      ',[pm_medic_longterm] ' +
      ',[pm_medic_notes] ' +
      ',[pm_frequency] ' +
      ',[pm_dates] ' +
      ',[pm_start_date] ' +
      ',[pm_end_date] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpetmedic'
	exec sp_executesql @sql
	set identity_insert tblpetmedic off
print 'tblpetscore'
	-----------------------------------------------------
	delete from tblpetscore
	--set identity_insert tblpetscore on
	select @sql = 'insert into tblpetscore ' +
		'([ps_pet_no] ' +
      ',[ps_sv_no] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpetscore'
	exec sp_executesql @sql
	--set identity_insert tblpetscore off
print 'tblpetweight'
	-----------------------------------------------------
	delete from tblpetweight
	--set identity_insert tblpetweight on
	select @sql = 'insert into tblpetweight ' +
		'([pw_pet_no] ' +
      ',[pw_date] ' +
      ',[pw_weight] ' +
      ',[pw_notes] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpetweight'
	exec sp_executesql @sql
	--set identity_insert tblpetweight off
print 'tblpickup'
	-----------------------------------------------------
	delete from tblpickup
	set identity_insert tblpickup on
	select @sql = 'insert into tblpickup ' +
		'([pickup_no] ' +
      ',[pickup_zonecode] ' +
      ',[pickup_rate] ' +
      ',[pickup_ratetype] ' +
      ',[pickup_inactive] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpickup'
	exec sp_executesql @sql
	set identity_insert tblpickup off
print 'tblpickupstatus'
	-----------------------------------------------------
	delete from tblpickupstatus
	set identity_insert tblpickupstatus on
	select @sql = 'insert into tblpickupstatus ' +
		'([ps_no] ' +
      ',[ps_status] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblpickupstatus'
	exec sp_executesql @sql
	set identity_insert tblpickupstatus off
print 'tblrate'
	-----------------------------------------------------
	delete from tblrate
	--set identity_insert tblrate on
	select @sql = 'insert into tblrate ' +
		'([r_key] ' +
      ',[r_srv_no] ' +
      ',[r_srv_rate] ' +
      ',[r_peak] ' +
      ',[r_billtype] ' +
      ',[r_date] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrate'
	exec sp_executesql @sql
	--set identity_insert tblrate off
print 'tblreport'
	-----------------------------------------------------
	delete from tblreport
	set identity_insert tblreport on
	select @sql = 'insert into tblreport ' +
		'([rep_no] ' +
      ',[rep_name] ' +
      ',[rep_active] ' +
      ',[rep_header] ' +
      ',[rep_translate] ' +
      ',[rep_email_no] ' +
      ',[rep_timestamp] ' +
      ',[rep_triggers] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblreport'
	exec sp_executesql @sql
	set identity_insert tblreport off
print 'tblresource'
	-----------------------------------------------------
	delete from tblresource
	set identity_insert tblresource on
	select @sql = 'insert into tblresource ' +
		'([res_no] ' +
      ',[res_bk_type] ' +
      ',[res_desc] ' +
      ',[res_start_time] ' +
      ',[res_end_time] ' +
      ',[res_max] ' +
      ',[res_day] ' +
      ',[res_inactive] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblresource'
	exec sp_executesql @sql
	set identity_insert tblresource off
print 'tblresourcetask'
	-----------------------------------------------------
	delete from tblresourcetask
	set identity_insert tblresourcetask on
	select @sql = 'insert into tblresourcetask ' +
		'([restask_no] ' +
      ',[ResourceID] ' +
      ',[ResourceName] ' +
      ',[Color] ' +
      ',[ResourceImage] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblresourcetask'
	exec sp_executesql @sql
	set identity_insert tblresourcetask off
print 'tblrtf'
	-----------------------------------------------------
	delete from tblrtf
	set identity_insert tblrtf on
	select @sql = 'insert into tblrtf ' +
		'([rtf_no] ' +
      ',[rtf_name] ' +
      ',[rtf_desc] ' +
      ',[rtf_path] ' +
      ',[rtf_locations] ' +
      ',[rtf_email_no] ' +
      ',[rtf_advanced] ' +
      ',[rtf_triggers] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrtf'
	exec sp_executesql @sql
	set identity_insert tblrtf off
print 'tblrun'
	-----------------------------------------------------
	delete from tblrun
	set identity_insert tblrun on
	select @sql = 'insert into tblrun ' +
		'([run_no] ' +
      ',[run_code] ' +
      ',[run_max_no] ' +
      ',[run_spec_no] ' +
      ',[run_rs_no] ' +
      ',[run_rt_no] ' +
      ',[run_inactive] ' +
      ',[run_group] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrun'
	exec sp_executesql @sql
	set identity_insert tblrun off
print 'tblrunclosed'
	-----------------------------------------------------
	delete from tblrunclosed
	set identity_insert tblrunclosed on
	select @sql = 'insert into tblrunclosed ' +
		'([rc_no] ' +
      ',[rc_run_no] ' +
      ',[rc_start_date] ' +
      ',[rc_end_date] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrunclosed'
	exec sp_executesql @sql
	set identity_insert tblrunclosed off
print 'tblrunmap'
	-----------------------------------------------------
	delete from tblrunmap
	set identity_insert tblrunmap on
	select @sql = 'insert into tblrunmap ' +
		'([rm_no] ' +
      ',[rm_name] ' +
      ',[rm_map] ' +
      ',[rm_font_size] ' +
      ',[rm_landscape] ' +
      ',[rm_A4] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrunmap'
	exec sp_executesql @sql
	set identity_insert tblrunmap off
print 'tblrunmapcode'
	-----------------------------------------------------
	delete from tblrunmapcode
	set identity_insert tblrunmapcode on
	select @sql = 'insert into tblrunmapcode ' +
		'([rmc_no] ' +
      ',[rmc_rm_no] ' +
      ',[rmc_run_no] ' +
      ',[rmc_x] ' +
      ',[rmc_y] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrunmapcode'
	exec sp_executesql @sql
	set identity_insert tblrunmapcode off
print 'tblrunspec'
	-----------------------------------------------------
	delete from tblrunspec
	--set identity_insert tblrunspec on
	select @sql = 'insert into tblrunspec ' +
		'([rsp_run_no] ' +
      ',[rsp_spec_no] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrunspec'
	exec sp_executesql @sql
	--set identity_insert tblrunspec off
print 'tblrunoccupancy'
	-----------------------------------------------------
	delete from tblrunoccupancy
	--set identity_insert tblrunoccupancy on
	select @sql = 'insert into tblrunoccupancy ' +
		'([ro_run_no] ' +
      ',[ro_pet_no] ' +
      ',[ro_date] ' +
      ',[ro_bk_no] ' +
      ',[ro_isolated] ' +
      ',[ro_ignore] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrunoccupancy where ro_run_no is not null'
	exec sp_executesql @sql
	--set identity_insert tblrunoccupancy off
print 'tblrunsize'
	-----------------------------------------------------
	delete from tblrunsize
	set identity_insert tblrunsize on
	select @sql = 'insert into tblrunsize ' +
		'([rs_no] ' +
      ',[rs_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblrunsize'
	exec sp_executesql @sql
	set identity_insert tblrunsize off
print 'tblruntype'
	-----------------------------------------------------
	delete from tblruntype 
	set identity_insert tblruntype  on
	select @sql = 'insert into tblruntype  ' +
		'([rt_no] ' +
      ',[rt_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblruntype '
	exec sp_executesql @sql
	set identity_insert tblruntype  off
print 'tblscheduletask'
	-----------------------------------------------------
	delete from tblscheduletask 
	set identity_insert tblscheduletask  on
	select @sql = 'insert into tblscheduletask ' +
		'([schtask_no] ' +
      ',[AllDay] ' +
      ',[Description] ' +
      ',[EndTime] ' +
      ',[Label] ' +
      ',[Location] ' +
      ',[RecurrenceInfo] ' +
      ',[ReminderInfo] ' +
      ',[ResourceID] ' +
      ',[StartTime] ' +
      ',[Status] ' +
      ',[Subject] ' +
      ',[EventType] ' +
      ',[tsk_bk_no] ' +
      ',[tsk_cust_no] ' +
      ',[tsk_pet_no] ' +
      ',[tsk_srv_no] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblscheduletask '
	exec sp_executesql @sql
	set identity_insert tblscheduletask  off
print 'tblscoreresult'
	-----------------------------------------------------
	delete from tblscoreresult 
	set identity_insert tblscoreresult  on
	select @sql = 'insert into tblscoreresult ' +
		'([sr_no] ' +
      ',[sr_desc] ' +
      ',[sr_min] ' +
      ',[sr_max] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblscoreresult '
	exec sp_executesql @sql
	set identity_insert tblscoreresult  off
print 'tblscoretype'
	-----------------------------------------------------
	delete from tblscoretype 
	set identity_insert tblscoretype  on
	select @sql = 'insert into tblscoretype ' +
		'([st_no] ' +
      ',[st_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblscoretype '
	exec sp_executesql @sql
	set identity_insert tblscoretype  off
print 'tblscorevalue'
	-----------------------------------------------------
	delete from tblscorevalue 
	set identity_insert tblscorevalue  on
	select @sql = 'insert into tblscorevalue ' +
		'([sv_no] ' +
      ',[sv_st_no] ' +
      ',[sv_desc] ' +
      ',[sv_value] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblscorevalue '
	exec sp_executesql @sql
	set identity_insert tblscorevalue  off
print 'tblsecurity'
	-----------------------------------------------------
	delete from tblsecurity 
	--set identity_insert tblsecurity  on
	select @sql = 'insert into tblsecurity ' +
		'([sec_u_no] ' +
      ',[sec_code] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblsecurity '
	exec sp_executesql @sql
	--set identity_insert tblsecurity  off
print 'tblservice'
	-----------------------------------------------------
	delete from tblservice 
	set identity_insert tblservice  on
	select @sql = 'insert into tblservice ' +
		'([srv_no] ' +
      ',[srv_code] ' +
      ',[srv_desc] ' +
      ',[srv_system] ' +
      ',[srv_vat_percentage] ' +
      ',[srv_vat2_percentage] ' +
      ',[srv_position] ' +
      ',[srv_report] ' +
      ',[srv_bk_type] ' +
      ',[srv_bill_type] ' +
      ',[srv_inactive] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblservice '
	exec sp_executesql @sql
	set identity_insert tblservice  off
print 'tblserviceitem'
	-----------------------------------------------------
	delete from tblserviceitem 
	--set identity_insert tblserviceitem  on
	select @sql = 'insert into tblserviceitem ' +
		'([si_bk_no] ' +
      ',[si_srv_no] ' +
      ',[si_pet_no] ' +
      ',[si_date] ' +
      ',[si_units] ' +
      ',[si_peak] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblserviceitem '
	exec sp_executesql @sql
	--set identity_insert tblserviceitem  off
print 'tblservicenote'
	-----------------------------------------------------
	delete from tblservicenote 
	--set identity_insert tblservicenote  on
	select @sql = 'insert into tblservicenote ' +
		'([sn_bk_no] ' +
      ',[sn_srv_no] ' +
      ',[sn_pet_no] ' +
      ',[sn_notes] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblservicenote '
	exec sp_executesql @sql
	--set identity_insert tblservicenote  off
print 'tblsms'
	-----------------------------------------------------
	delete from tblsms 
	set identity_insert tblsms  on
	select @sql = 'insert into tblsms ' +
		'([sms_no] ' +
      ',[sms_code] ' +
      ',[sms_text] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblsms '
	exec sp_executesql @sql
	set identity_insert tblsms  off
print 'tblsource'
	-----------------------------------------------------
	delete from tblsource 
	set identity_insert tblsource  on
	select @sql = 'insert into tblsource ' +
		'([src_no] ' +
      ',[src_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblsource '
	exec sp_executesql @sql
	set identity_insert tblsource  off
print 'tblspecies'
	-----------------------------------------------------
	delete from tblspecies 
	set identity_insert tblspecies  on
	select @sql = 'insert into tblspecies ' +
		'([spec_no] ' +
      ',[spec_desc] ' +
      ',[spec_max_places] ' +
      ',[spec_alert_peak] ' +
      ',[spec_alert_low] ' +
      ',[spec_alert] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblspecies '
	exec sp_executesql @sql
	set identity_insert tblspecies  off
print 'tblstandby'
	-----------------------------------------------------
	delete from tblstandby 
	set identity_insert tblstandby  on
	select @sql = 'insert into tblstandby ' +
		'([sb_no] ' +
      ',[sb_cust_no] ' +
      ',[sb_spec_no] ' +
      ',[sb_startdate] ' +
      ',[sb_enddate] ' +
      ',[sb_number] ' +
      ',[sb_requestdate] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblstandby '
	exec sp_executesql @sql
	set identity_insert tblstandby  off
print 'tblsurcharge'
	-----------------------------------------------------
	delete from tblsurcharge 
	set identity_insert tblsurcharge  on
	select @sql = 'insert into tblsurcharge ' +
		'([sur_no] ' +
      ',[sur_pay_type] ' +
      ',[sur_type] ' +
      ',[sur_percentage] ' +
      ',[sur_amount] ' +
      ',[sur_desc] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblsurcharge '
	exec sp_executesql @sql
	set identity_insert tblsurcharge  off
print 'tblsystem'
	-----------------------------------------------------
	delete from tblsystem 
	--set identity_insert tblsystem  on
	select @sql = 'insert into tblsystem ' +
		'([sys_id] ' +
      ',[sys_type] ' +
      ',[sys_description] ' +
      ',[sys_value] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblsystem '
	exec sp_executesql @sql
	--set identity_insert tblsystem  off
print 'tbltitle'
	-----------------------------------------------------
	delete from tbltitle 
	set identity_insert tbltitle  on
	select @sql = 'insert into tbltitle ' +
		'([title_no] ' +
      ',[title] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbltitle '
	exec sp_executesql @sql
	set identity_insert tbltitle  off
print 'tbltrainday'
	-----------------------------------------------------
	delete from tbltrainday 
	set identity_insert tbltrainday  on
	select @sql = 'insert into tbltrainday ' +
		'([td_no] ' +
      ',[td_ti_no] ' +
      ',[td_tr_no] ' +
      ',[td_day] ' +
      ',[td_time] ' +
      ',[td_date] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbltrainday '
	exec sp_executesql @sql
	set identity_insert tbltrainday  off
print 'tbltraining'
	-----------------------------------------------------
	delete from tbltraining 
	set identity_insert tbltraining  on
	select @sql = 'insert into tbltraining ' +
		'([tr_no] ' +
      ',[tr_name] ' +
      ',[tr_duration] ' +
      ',[tr_places] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbltraining '
	exec sp_executesql @sql
	set identity_insert tbltraining  off
print 'tbltrainitem'
	-----------------------------------------------------
	delete from tbltrainitem 
	set identity_insert tbltrainitem  on
	select @sql = 'insert into tbltrainitem ' +
		'([ti_no] ' +
      ',[ti_tr_no] ' +
      ',[ti_duration] ' +
      ',[ti_startdate] ' +
      ',[ti_places] ' +
      ',[ti_taken] ' +
      ',[ti_mon] ' +
      ',[ti_tue] ' +
      ',[ti_wed] ' +
      ',[ti_thu] ' +
      ',[ti_fri] ' +
      ',[ti_sat] ' +
      ',[ti_sun] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbltrainitem '
	exec sp_executesql @sql
	set identity_insert tbltrainitem  off
print 'tbltranslate'
	-----------------------------------------------------
	delete from tbltranslate 
	set identity_insert tbltranslate  on
	select @sql = 'insert into tbltranslate ' +
		'([trans_no] ' +
      ',[trans_match] ' +
      ',[trans_from] ' +
      ',[trans_to] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbltranslate '
	exec sp_executesql @sql
	set identity_insert tbltranslate  off
print 'tblvatrate'
	-----------------------------------------------------
	delete from tblvatrate 
	set identity_insert tblvatrate  on
	select @sql = 'insert into tblvatrate ' +
		'([vat_no] ' +
      ',[vat_code] ' +
      ',[vat_desc] ' +
      ',[vat_percentage] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblvatrate '
	exec sp_executesql @sql
	set identity_insert tblvatrate  off
print 'tblvet'
	-----------------------------------------------------
	delete from tblvet 
	set identity_insert tblvet  on
	select @sql = 'insert into tblvet ' +
		'([vet_no] ' +
      ',[vet_practice_name] ' +
      ',[vet_addr1] ' +
      ',[vet_addr2] ' +
      ',[vet_addr3] ' +
      ',[vet_postcode] ' +
      ',[vet_telno_1] ' +
      ',[vet_telno_2] ' +
      ',[vet_faxno] ' +
      ',[vet_notes] ' +
      ',[vet_addr2a] ' +
      ',[vet_addr2b] ' +
      ',[vet_email] ' +
      ',[vet_website] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblvet '
	exec sp_executesql @sql
	set identity_insert tblvet  off
print 'tbluser'
	-----------------------------------------------------
	delete from tbluser
	set identity_insert tbluser on
	select @sql = 'insert into tbluser ' +
		'([u_no] '+
		',[u_init] '+
		',[u_name] '+
		',[u_password] '+
		',[u_state] '+
		',[u_timeout] '+
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tbluser'
	exec sp_executesql @sql
	set identity_insert tbluser off
print 'tblweight'
	-----------------------------------------------------
	delete from tblweight
	set identity_insert tblweight on
	select @sql = 'insert into tblweight ' +
		'([weight_no] ' +
      ',[weight_min] ' +
      ',[weight_max] ' +
		') ' +
		'select * from OpenDataSource(''' + @conn + ''', ''Data Source=' + 
									@dbpath + ''')...tblweight'
	exec sp_executesql @sql
	set identity_insert tblweight off

END
