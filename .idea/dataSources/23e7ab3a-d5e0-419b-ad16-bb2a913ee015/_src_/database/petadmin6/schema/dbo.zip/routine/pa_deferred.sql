CREATE PROCEDURE [dbo].[pa_deferred] 
	@repname nvarchar(25),
	@date1 datetime,
	@date2 datetime
AS
BEGIN
	declare @sql nvarchar(max)
	declare @err int

	SET NOCOUNT ON

	-- Strip time from dates
	set @date1 = DATEADD(d, 0, DATEDIFF(d, 0, @date1))
	if not @date2 is null
		set @date2 = DATEADD(d, 0, DATEDIFF(d, 0, @date2))

	-- Now delete records older than 3 months
	delete from tbldeferred
	where t_create_date < dateadd(m, -3, GETDATE())

	-- Now delete records from a previous failed run
	delete from tbldeferred
	where t_create_date is null

	-- Finally, delete records for same report for same parameters
	if (@repname = 'Revenue')
		delete from tbldeferred
		where t_report = @repname
		and t_date1 = @date1
		and t_date2 is null
	else
		delete from tbldeferred
		where t_report = @repname
		and t_date1 = @date1
		and t_date2 = @date2

	if (@repname = 'Discount')
	begin
        insert into tbldeferred (bk_type, si_bk_no, si_srv_no, 
								si_pet_no, si_sum, si_value, 
								srv_report, srv_code, cust_no, 
								cust_surname, cust_postcode, spec_no, 
								spec_desc, ii_rate, ii_vat_percentage, 
								ii_vat2_percentage, netamt, grossamt, 
								ii_vat, ii_vat2, bk_gross_amt, 
								bk_disc_total, bk_paid_amt, bk_start_date,
								bk_end_date, date1, date2, 
								bk_days, bk_overlap_days, bk_status)
		select bk_type, bk_no, 0, 
				0, 1, 0, 
				'', '', cust_no, 
				cust_surname, cust_postcode, -2, 
				'Discount', -bk_disc_total, 0, 
				0, 0, 0, 
				-bk_disc_vat, -bk_disc_vat2, bk_gross_amt, 
				0, bk_paid_amt, bk_start_date, 
				bk_end_date, @date1, @date2,
				datediff(d, bk_start_date, bk_end_date)+1, 0, bk_status
				from tblbooking, tblcustomer
				where bk_start_date <= @date2
				and bk_end_date >= @date1
				and bk_disc_total <> 0
				and bk_cust_no = cust_no 
	end
	else -- Income or Revenue
	begin
		-- service income records
        insert into tbldeferred (bk_type, si_bk_no, si_srv_no, 
								si_pet_no, si_sum, si_value, 
								srv_report, srv_code, cust_no, 
								cust_surname, cust_postcode, spec_no, 
								spec_desc, ii_rate, ii_vat_percentage, 
								ii_vat2_percentage, netamt, grossamt, 
								ii_vat, ii_vat2, bk_gross_amt, 
								bk_disc_total, bk_paid_amt, bk_start_date,
								bk_end_date, date1, date2, 
								bk_days, bk_overlap_days, bk_status)
		select bk_type, si_bk_no, si_srv_no, 
				si_pet_no, SUM(si_units), 0, 
				srv_report, srv_code, cust_no, 
				cust_surname, cust_postcode, spec_no, 
				spec_desc, ii_rate, ii_vat_percentage, 
				ii_vat2_percentage, 0, 0, 
				0, 0, bk_gross_amt, 
				bk_disc_total, bk_paid_amt, null, 
				null, @date1, @date2, 
				0, 0, bk_status
				from tblbooking, tblserviceitem, tblcustomer, tblpet, tblinvitem, tblspecies, tblservice
				where si_date between @date1 and
				case 
					when @date2 is null then cast('9999-12-31' as datetime)
					else @date2
				end
				and bk_no = si_bk_no
				and si_bk_no = ii_bk_no
				and si_pet_no = ii_pet_no
				and si_srv_no = srv_no
				and ii_pet_no = pet_no
				and si_srv_no = ii_srv_no
				and si_peak = ii_peak
				and pet_cust_no = cust_no
				and pet_spec_no = spec_no
				group by bk_type, si_bk_no, si_srv_no,
					si_pet_no, srv_report, srv_code,
					cust_no, cust_surname, cust_postcode,
					spec_no, spec_desc, ii_rate,
					ii_vat_percentage, ii_vat2_percentage, bk_gross_amt,
					bk_disc_total, bk_paid_amt, bk_status


		-- extra income records (ignore event bookings)
        insert into tbldeferred (bk_type, si_bk_no, si_srv_no, 
								si_pet_no, si_sum, si_value, 
								srv_report, srv_code, cust_no, 
								cust_surname, cust_postcode, spec_no, 
								spec_desc, ii_rate, ii_vat_percentage, 
								ii_vat2_percentage, netamt, grossamt, 
								ii_vat, ii_vat2, bk_gross_amt, 
								bk_disc_total, bk_paid_amt, bk_start_date,
								bk_end_date, date1, date2, 
								bk_days, bk_overlap_days, bk_status)
		select bk_type, bk_no, 0, 
				0, ie_quantity, 0, 
				'', 'Extras', cust_no, 
				cust_surname, cust_postcode, -1, 
				'Extras', ie_unit_price, ie_vat_percentage, 
				ie_vat2_percentage, 0, 0, 
				0, 0, bk_gross_amt, 
				bk_disc_total, bk_paid_amt, bk_start_date, 
				bk_end_date, @date1, @date2, 
				datediff(d, bk_start_date, bk_end_date)+1, 0, bk_status
				from tblbooking, tblinvextra, tblcustomer
				where bk_end_date >= @date1
				and bk_start_date <=
				case 
					when @date2 is null then cast('9999-12-31' as datetime)
					else @date2
				end
				and bk_no = ie_bk_no
				and bk_cust_no = cust_no
				and bk_type <> 'E'

		-- event bookings but use event name instead of service code
        insert into tbldeferred (bk_type, si_bk_no, si_srv_no, 
								si_pet_no, si_sum, si_value, 
								srv_report, srv_code, cust_no, 
								cust_surname, cust_postcode, spec_no, 
								spec_desc, ii_rate, ii_vat_percentage, 
								ii_vat2_percentage, netamt, grossamt, 
								ii_vat, ii_vat2, bk_gross_amt, 
								bk_disc_total, bk_paid_amt, bk_start_date,
								bk_end_date, date1, date2, 
								bk_days, bk_overlap_days, bk_status)
		select bk_type, bk_no, 0, 
				0, ie_quantity, 0, 
				'', ev_name, cust_no, 
				cust_surname, cust_postcode, -1, 
				'Extras', ie_unit_price, ie_vat_percentage, 
				ie_vat2_percentage, 0, 0, 
				0, 0, bk_gross_amt, 
				bk_disc_total, bk_paid_amt, bk_start_date, 
				bk_end_date, @date1, @date2, 
				datediff(d, bk_start_date, bk_end_date)+1, 0, bk_status
				from tblbooking, tblinvextra, tblcustomer, tblevent
				where bk_end_date >= @date1
				and bk_start_date <=
				case 
					when @date2 is null then cast('9999-12-31' as datetime)
					else @date2
				end
				and bk_no = ie_bk_no
				and bk_cust_no = cust_no
				and bk_type = 'E'
				and bk_ev_no = ev_no
	end

	-- Update discount/extra income records
	if (@date2 is null)
	begin
		update tbldeferred
		set bk_overlap_days = datediff(d, bk_start_date, bk_end_date) + 1
		where bk_start_date >= @date1
		and spec_desc in ('Discount','Extras')
		and t_create_date is null

		update tbldeferred
		set bk_overlap_days = datediff(d, @date1, bk_end_date) + 1
		where bk_start_date < @date1
		and spec_desc in ('Discount','Extras')
		and t_create_date is null
	end
	else
	begin
		update tbldeferred
		set bk_overlap_days = datediff(d, @date1, @date2) + 1
		where bk_start_date <= @date1 and bk_end_date >= @date2
		and spec_desc in ('Discount','Extras')
		and t_create_date is null

		update tbldeferred
		set bk_overlap_days = datediff(d, @date1, bk_end_date) + 1
		where bk_start_date <= @date1 and bk_end_date <= @date2
		and spec_desc in ('Discount','Extras')
		and t_create_date is null

		update tbldeferred
		set bk_overlap_days = datediff(d, bk_start_date, bk_end_date) + 1
		where bk_start_date >= @date1 and bk_end_date <= @date2
		and spec_desc in ('Discount','Extras')
		and t_create_date is null

		update tbldeferred
		set bk_overlap_days = datediff(d, bk_start_date, @date2) + 1
		where bk_start_date >= @date1 and bk_end_date >= @date2
		and spec_desc in ('Discount','Extras')
		and t_create_date is null
	end

    update tbldeferred
	set ii_rate = ii_rate * bk_overlap_days / bk_days
	where spec_desc in ('Discount','Extras')
	and t_create_date is null

	-- Don't forget to apportion Discount VAT down
    update tbldeferred
	set ii_vat = ii_vat * bk_overlap_days / bk_days,
		ii_vat2 = ii_vat2 * bk_overlap_days / bk_days
	where spec_desc = 'Discount'
	and t_create_date is null
    
	-- Group the srv_report='Y' entries together
    update tbldeferred 
	set srv_code = 'Extra Services'
	where srv_report='Y'
	and t_create_date is null

	-- Set the booking type descriptions
	update tbldeferred set bk_type_desc='Boarding' where bk_type='B'
	update tbldeferred set bk_type_desc='Training' where bk_type='T'
	update tbldeferred set bk_type_desc='Day Camp' where bk_type='P'
	update tbldeferred set bk_type_desc='Hydrotherapy' where bk_type='H'
	update tbldeferred set bk_type_desc='Grooming' where bk_type='G'
	update tbldeferred set bk_type_desc='Events' where bk_type='E'
	update tbldeferred set bk_type_desc='Clubs' where bk_type='C'

	declare @vat_reg nvarchar(1)
	declare @vat_rates nvarchar(10)
	declare @vat_name2 nvarchar(10)
	select @vat_reg = sys_value from tblsystem where sys_id='gPref1'
	select @vat_rates = sys_value from tblsystem where sys_id='gPref3'
	select @vat_name2 = sys_value from tblsystem where sys_id='gPref5'

	----------------------------------------------------------------------------
	-- Calculate the income values
	declare @t_key integer
	declare @si_sum integer
	declare @ii_rate money
	declare @ii_vat_percentage numeric(18,3)
	declare @ii_vat2_percentage numeric(18,3)
	declare @spec_desc nvarchar(20)
	declare @ii_vat money
	declare @ii_vat2 money
	declare @bk_gross_amt money
	declare @bk_paid_amt money
	declare @bk_disc_total money
	declare @netamt money
	declare @grossamt money
	declare @si_value money
	declare @amount money
	declare @net money
	declare @gross money
	declare @vat money
	declare @vat2 money

	declare recs cursor for
		select t_key, si_sum, ii_rate, 
				ii_vat_percentage, ii_vat2_percentage, spec_desc, 
				ii_vat, ii_vat2, bk_gross_amt, 
				bk_paid_amt, bk_disc_total,
				netamt, grossamt
		from tbldeferred
		where t_create_date is null

	open recs
	fetch next from recs into
		@t_key, @si_sum, @ii_rate,
		@ii_vat_percentage, @ii_vat2_percentage, @spec_desc,
		@ii_vat, @ii_vat2, @bk_gross_amt,
		@bk_paid_amt, @bk_disc_total,
		@netamt, @grossamt

	if (@@cursor_rows = 0)
	begin
		return	-- no records
	end

	while (@@fetch_status = 0)
	begin
		set @amount = @si_sum * @ii_rate

		-- Note: gross figure includes the discount
		if @spec_desc <> 'Discount'
		begin
			if @bk_gross_amt = 0
				set @amount = 0
			else
			begin
				if @bk_disc_total <> 0
				begin
					if @bk_gross_amt + @bk_disc_total = 0	-- avoid div by 0
						set @amount = 0
					else
						set @amount = @amount * @bk_gross_amt / (@bk_gross_amt + @bk_disc_total)
				end
			end
		end

		if @vat_reg = 'Y'
		begin
			if @spec_desc = 'Discount'
			begin
				set @vat = @ii_vat
				set @vat2 = @ii_vat2
			end
			else
			begin
				if @vat_name2 = ''
				begin
					if @vat_rates = 'net'
						set @vat = @ii_vat_percentage * @amount / 100.0
					else
						set @vat = @ii_vat_percentage * @amount / (100.0 + @ii_vat_percentage)
					set @vat2 = 0
				end
				else
				begin
					if @vat_rates = 'net'
					begin
						set @vat = @ii_vat_percentage * @amount / 100.0
						set @vat2 = @ii_vat2_percentage * @amount / 100.0
					end
					else
					begin
						if @ii_vat_percentage + @ii_vat2_percentage = 0
						begin
							set @vat = 0
							set @vat2 = 0
						end
						else
						begin
							declare @vatamount numeric(18,4)
							set @vatamount = (@ii_vat_percentage + @ii_vat2_percentage) * @amount / (100.0 + @ii_vat_percentage + @ii_vat2_percentage)
							set @vat = @vatamount * @ii_vat_percentage / (@ii_vat_percentage + @ii_vat2_percentage)
							set @vat2 = @vatamount * @ii_vat2_percentage / (@ii_vat_percentage + @ii_vat2_percentage)
						end
					end
				end
                --@vat = fn_roundVAT(@vat)
                --@vat2 = fn_roundVAT(@vat2)
			end

			if @vat_rates = 'net'
			begin
				set @net = @amount
				set @gross = @net + @vat + @vat2
			end
			else
			begin
				set @gross = @amount
				set @net = @gross - @vat - @vat2
			end
		end
		else
		begin
			set @net = @amount
			set @gross = @amount
			set @vat = 0
			set @vat2 = 0
		end
		set @si_value = @net -- actual net booking value

		-- Apportion according to amount paid (but avoid div ny 0)
		if @bk_gross_amt <> @bk_paid_amt And @bk_gross_amt <> 0
		begin
			set @net = @net * @bk_paid_amt / @bk_gross_amt
			set @gross = @gross * @bk_paid_amt / @bk_gross_amt
			set @vat = @vat * @bk_paid_amt / @bk_gross_amt
			set @vat2 = @vat2 * @bk_paid_amt / @bk_gross_amt
		end

		update tbldeferred
		set netamt = @net,
			grossamt = @gross,
			si_value = @si_value,
			ii_vat = @vat,
			ii_vat2 = @vat2
		where current of recs

		fetch next from recs into
			@t_key, @si_sum, @ii_rate,
			@ii_vat_percentage, @ii_vat2_percentage, @spec_desc,
			@ii_vat, @ii_vat2, @bk_gross_amt,
			@bk_paid_amt, @bk_disc_total,
			@netamt, @grossamt
	end
	close recs
	deallocate recs

	----------------------------------------------------------------------------

	-- Finally stamp the records
	update tbldeferred
	set t_create_date = DATEADD(d, 0, DATEDIFF(d, 0, GETDATE())),
		t_report = @repname,
		t_date1 = @date1,
		t_date2 = @date2
	where t_create_date is null

END
