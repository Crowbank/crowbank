CREATE view [dbo].[change_log_dump_sql] as
select change_sql from change_log
where change_sql is not null and isnull(dumped, 0) = 0
