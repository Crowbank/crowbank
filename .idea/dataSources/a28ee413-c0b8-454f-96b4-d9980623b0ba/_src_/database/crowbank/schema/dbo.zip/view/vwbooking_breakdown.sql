create view [dbo].[vwbooking_breakdown]
As
select bk_no bd_bk_no, sum(case when pet_spec_no = 1 then ii_net_amt else 0 end) bd_dogs,
sum(case when pet_spec_no = 2 then ii_net_amt else 0 end) bd_cats, IsNull(ie_vet, 0) bd_vet, IsNull(ie_other, 0) bd_other, bk_gross_amt bd_gross_amt, bk_disc_total bd_discount
from petadmin6..tblbooking
join petadmin6..tblinvitem on ii_bk_no = bk_no
join petadmin6..tblpet on pet_no = ii_pet_no
left join (select ie_bk_no, sum(case when ie_desc like '%Vet%' then ie_total end) ie_vet,
sum(case when ie_desc not like '%Vet%' then ie_total end) ie_other from petadmin6..tblinvextra group by ie_bk_no) ie on ie_bk_no = bk_no
group by bk_no, bk_gross_amt, ie_vet, ie_other, bk_disc_total
