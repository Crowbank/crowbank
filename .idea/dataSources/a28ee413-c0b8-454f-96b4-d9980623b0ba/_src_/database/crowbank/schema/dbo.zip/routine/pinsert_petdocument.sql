create procedure pinsert_petdocument (@pet_no int, @pd_path varchar(999))
as
Insert into petadmin6..tblpetdocument (pd_pet_no, pd_desc, pd_path)
values (@pet_no, 'Vaccination Card', @pd_path)
