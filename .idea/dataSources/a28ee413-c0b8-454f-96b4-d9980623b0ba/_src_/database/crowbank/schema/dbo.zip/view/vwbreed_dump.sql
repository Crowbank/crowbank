create view [dbo].[vwbreed_dump] as
select breed_no, spec_desc breed_spec, breed_desc, billcat_desc breed_billcat
from petadmin6..tblbreed
join petadmin6..tblspecies on spec_no = breed_spec_no
join petadmin6..tblbillcategory on billcat_no = breed_billcat_no
