CREATE procedure [dbo].[ppayment] @bk_no int, @amount money, @type varchar(100), @date date
As
Declare @cust_no int
Declare @cust_Surname varchar(100)
Declare @current_date date
Declare @current_time datetime

select @cust_no = bk_cust_no from petadmin6..tblbooking where bk_no = @bk_no
select @cust_Surname = cust_surname from petadmin6..tblcustomer where cust_no = @cust_no
select @current_Date = GETDATE()
select @current_time = GETDATE()

Insert into petadmin6..tblpayment (pay_bk_no, pay_cust_no, pay_date, pay_amount, pay_type, pay_ref, pay_surcharge, pay_total)
values (@bk_no, @cust_no, @date, @amount, @type, '', 0.0, @amount)

Update petadmin6..tblbooking set bk_paid_amt = bk_paid_amt + @amount, bk_amt_outstanding = bk_amt_outstanding - @amount, bk_status = 'V' where bk_no = @bk_no

Insert into petadmin6..tblaudit (aud_init, aud_key, aud_type, aud_action, aud_date, aud_time, aud_cust_no, aud_cust_surname, aud_bk_start_date, aud_bk_end_date, aud_amount)
values
('', @bk_no, 'P', 'A', @current_date, Left(Convert(varchar(6), @current_time, 114), 5), @cust_no, @cust_surname, '1970-01-01 00:00:00.000', '1970-01-01 00:00:00.000', @amount)
