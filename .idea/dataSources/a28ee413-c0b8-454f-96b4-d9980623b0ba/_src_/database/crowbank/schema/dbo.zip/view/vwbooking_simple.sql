CREATE view [dbo].[vwbooking_simple] As
Select bk_no, bk_cust_no, bk_start_date, bk_end_date, bk_start_time, bk_end_time, bk_start_date + bk_start_time bk_start_datetime, bk_end_date + bk_end_time bk_end_datetime,
bk_gross_amt, bk_paid_amt, bk_disc_value, bk_disc_type, bk_status, bk_create_date, Case when ii_bk_no is null then 0 else 1 end bk_peak, Case when dlx_bk_no is null then 0 else 1 end bk_deluxe,
Case when bk_memo like '%No Confirm%' then 1 else 0 end bk_skip_confirm, bk_amt_outstanding
from petadmin6..tblbooking
join petadmin6..tblcustomer on cust_no = bk_cust_no
left join (select distinct ii_bk_no from petadmin6..tblinvitem where ii_peak = 'P') i on ii_bk_no = bk_no
left join (select distinct ii_bk_no dlx_bk_no from petadmin6..tblinvitem where ii_srv_no in (15, 16, 19, 20)) d on dlx_bk_no = bk_no
