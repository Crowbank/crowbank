Create Procedure [dbo].[padd_weight] @pet_no int, @weight float, @date date = NULL
As
If @date is null
	Set @date = GETDATE()

update petadmin6..tblpet set pet_weight = @weight where pet_no = @pet_no
insert into petadmin6..tblpetweight (pw_pet_no, pw_date, pw_weight) values (@pet_no, @date, @weight)
