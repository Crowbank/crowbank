CREATE procedure [dbo].[ptest_triggers] as
declare @today date
set @today = getdate()
declare @cust_no int
declare @breed_no int
declare @vet_no int
declare @pet_no int
declare @bk_no int
declare @pay_no int

Insert into petadmin6..tblcustomer (cust_surname, cust_forename, cust_addr1, cust_addr3, cust_postcode, cust_telno_home, cust_email, cust_telno_mobile)
values ('Test', 'John', '100 Main Street', 'Any Town', 'G99 X99', '01236 123456', 'john@me.com', '07890 123456')

Select @cust_no = cust_no from petadmin6..tblcustomer where cust_surname = 'Test'

Update petadmin6..tblcustomer set cust_postcode = 'G99 Y99' where cust_no = @cust_no

Insert into petadmin6..tblbreed (breed_spec_no, breed_desc, breed_billcat_no) values (1, 'New Dog Breed', 5)

Select @breed_no = breed_no from petadmin6..tblbreed where breed_desc = 'New Dog Breed'

Update petadmin6..tblbreed set breed_desc = 'Very New Dog Breed' where breed_no = @breed_no

Insert into petadmin6..tblvet (vet_practice_name, vet_addr1, vet_addr3, vet_postcode, vet_telno_1, vet_email, vet_website)
values ('New Vet Practice', '100 High Street', 'Any Town', 'G99 8AB', '0141 123456', 'vets@vets.com', 'www.vets.com')

Select @vet_no = vet_no from tblvet where vet_practice_name = 'New Vet Practice'

Update petadmin6..tblvet set vet_practice_name = 'Very New Vet Practice' where vet_no = @vet_no

Insert into petadmin6..tblpet (pet_cust_no, pet_name, pet_spec_no, pet_breed_no, pet_dob, pet_sex, pet_vet_no)
values (@cust_no, 'Test', 1, @breed_no, '20150101', 'M', @vet_no)

Select @pet_no = pet_no from petadmin6..tblpet where pet_name = 'Test'

Update petadmin6..tblpet set pet_dob = '20140101' where pet_no = @pet_no

Insert into petadmin6..tblbooking (bk_cust_no, bk_start_date, bk_end_date, bk_start_time, bk_end_time, bk_gross_amt, bk_paid_amt, bk_amt_outstanding)
values (@cust_no, @today, dateadd(day, 10, @today), '10:00', '11:00', 150.0, 0.0, 150.0)

Select @bk_no = bk_no from petadmin6..tblbooking where bk_cust_no = @cust_no

Insert into petadmin6..tblbookingitem (bi_bk_no, bi_pet_no) values (@bk_no, @pet_no)

Insert into petadmin6..tblpayment (pay_bk_no, pay_cust_no, pay_date, pay_amount, pay_type) values (@bk_no, @cust_no, @today, 50.0, 'Cash')

Select @pay_no = pay_no from petadmin6..tblpayment where pay_bk_no = @bk_no

update petadmin6..tblpayment set pay_type = 'Debit Card' where pay_no = @pay_no

Update petadmin6..tblbooking set bk_paid_amt = 50.0, bk_amt_outstanding = 100.0 where bk_no = @bk_no

Delete from petadmin6..tblpayment where pay_no = @pay_no
Delete from petadmin6..tblbookingitem where bi_bk_no = @bk_no and bi_pet_no = @pet_no
Delete from petadmin6..tblbooking where bk_no = @bk_no
Delete from petadmin6..tblpet where pet_no = @pet_no
Delete from petadmin6..tblvet where vet_no = @vet_no
Delete from petadmin6..tblbreed where breed_no = @breed_no
Delete from petadmin6..tblcustomer where cust_no = @cust_no
