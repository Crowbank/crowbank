CREATE View [dbo].[vwcustomer]
As
Select
cust_no, cust_title, cust_surname, dbo.fnpet_desc(cust_no) cust_pets, cust_forename, cust_addr1, cust_addr2, cust_addr3, cust_postcode, cust_telno_home, cust_telno_mobile, cust_telno_mobile2, cust_email,
cust_notes, case when cust_notes like '%No Deposit%' then 1 else 0 end cust_nodeposit, cust_discount, case when dr_cust_no is null then 0 else 1 end cust_deposit_requested
from petadmin6..tblcustomer
left join (select distinct dr_cust_no from vwdepositrequest where dr_relevant = 1) dr on dr_cust_no = cust_no
