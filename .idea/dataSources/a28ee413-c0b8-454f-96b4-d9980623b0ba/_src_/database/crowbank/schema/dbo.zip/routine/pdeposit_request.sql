CREATE procedure [dbo].[pdeposit_request] (@bk_no int, @dr_amount money)
As
Declare @cust_no int

Select @cust_no = bk_cust_no from petadmin6..tblbooking where bk_no = @bk_no

If Exists (select * from tbldepositrequest where dr_bk_no = @bk_no)
	Delete from tbldepositrequest where dr_bk_no = @bk_no

Insert into tbldepositrequest (dr_bk_no, dr_date, dr_amount, dr_cust_no) values (@bk_no, GETDATE(), @dr_amount, @cust_no)
