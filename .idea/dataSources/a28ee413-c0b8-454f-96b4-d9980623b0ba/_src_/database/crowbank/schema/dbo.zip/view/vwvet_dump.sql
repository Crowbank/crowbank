create view [dbo].[vwvet_dump] as
select vet_no, vet_practice_name, vet_addr1, vet_addr2, vet_addr3, vet_postcode, vet_telno_1, vet_email, vet_website
from petadmin6..tblvet
