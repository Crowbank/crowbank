CREATE View [dbo].[vwinvcount] As
Select spec_desc spec, Convert(datetime, d.date) date,
SUM(case when in_out = '' then 1 end) stays,
SUM(case when in_out = 'In' then 1 end) ins,
SUM(case when in_out = 'Out' then 1 end) outs,
SUM(case when in_out = 'Day' then 1 end) days,
SUM(case when in_out in ('', 'Out') then 1 end) morning,
SUM(case when in_out in ('', 'In') then 1 end) evening,
SUM(1) lunch,
SUM(Case when in_out in ('', 'Out') then pet_count end) individuals,
rv_revenue
from tbldate d
join petadmin6..tblspecies s on 1=1
left join vwinventory i on i.date = d.date and i.spec = s.spec_desc
left Join vwrevenue r on rv_date = d.date
group by spec_desc, d.date, rv_revenue
