CREATE View [dbo].[vwkc_status] as
select bk_no kc_bk_no, kc_status, kc_desc from (
select bk_no, min(kc_status) kc_status from (
select bk_no, pet_no, case when pet_spec_no = 2 then 3 else
case when pi_innoculation_date is null then 0 else
case when datediff(day, pi_innoculation_date, bk_end_date) < 365 then 2 else 1 end
end
end kc_status
from petadmin6..tblbooking
join petadmin6..tblbookingitem on bi_bk_no = bk_no
join petadmin6..tblpet on pet_no = bi_pet_no
left join petadmin6..tblpetinnoculation on pi_pet_no = pet_no and pi_inn_no = 3) x
group by bk_no) y
join tblkc_status on kc_no = kc_status
