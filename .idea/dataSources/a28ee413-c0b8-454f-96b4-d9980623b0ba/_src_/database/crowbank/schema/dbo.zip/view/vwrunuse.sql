create view vwrunuse
as
select ro_date ru_date, spec_no ru_spec_no, bk_no ru_bk_no,
rt_no ru_rt_no, count(*) ru_c
from vwrunoccupancy
where bk_status in ('', 'V')
group by ro_date, spec_no, bk_no, rt_no, spec_no 
