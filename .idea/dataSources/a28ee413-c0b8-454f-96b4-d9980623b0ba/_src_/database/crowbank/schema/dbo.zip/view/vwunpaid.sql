CREATE View [dbo].[vwunpaid] as
Select date, Sum(case when pet_spec_no=1 then ii_rate end) * 5 / 6.0 unpaid_boarding_dogs,
Sum(case when pet_spec_no=2 then ii_rate end) * 5 / 6.0 unpaid_boarding_cats,
Sum(ii_rate) * 5 / 6.0 unpaid_boarding,
Sum(ii_rate) / 6.0 uncollected_vat
from tbldate
join petadmin6..tblrunoccupancy on 1=1
Join petadmin6..tblbooking on bk_no = ro_bk_no
Join petadmin6..tblinvitem on ii_bk_no = bk_no and ii_pet_no = ro_pet_no
join petadmin6..tblbookingitem on bi_bk_no = bk_no and bi_pet_no = ro_pet_no
join petadmin6..tblpet on pet_no = ro_pet_no
Left Join petadmin6..tblholiday on h_date = ro_date
where ro_ignore <> 'Y' and bk_status not in ('C', 'N') and ii_peak = IsNull(h_state, '')
and ro_date < date and bk_end_date >= date and bi_checkout_time = ''
group by date
