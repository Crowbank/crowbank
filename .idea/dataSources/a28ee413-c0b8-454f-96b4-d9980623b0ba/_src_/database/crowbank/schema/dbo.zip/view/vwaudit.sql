CREATE view [dbo].[vwaudit]
As
select aud_no, bk_no, aud_type, aud_action, aud_date+aud_time aud_datetime, aud_bk_start_date, aud_bk_end_date, aud_amount, Case when cust_notes like '%No Deposit%' then 1 else 0 end aud_nodeposit, bk_status, aud_date,
IsNull(c_c, 0) aud_booking_count
from petadmin6..tblaudit
join petadmin6..tblbooking on bk_no = aud_key
join petadmin6..tblcustomer on cust_no = bk_cust_no
left join (select bk_cust_no c_cust_no, count(*) c_c from petadmin6..tblbooking where bk_status in ('', 'V') and bk_start_date > GETDATE() group by bk_cust_no) c on c_cust_no = cust_no
where aud_type + aud_action in ('BA', 'BM', 'BC', 'PA')
and (aud_action <> 'M' or aud_bk_start_date <> '19700101' or aud_bk_end_date <> '19700101')
and (aud_type <> 'P' or aud_date < bk_start_date)
