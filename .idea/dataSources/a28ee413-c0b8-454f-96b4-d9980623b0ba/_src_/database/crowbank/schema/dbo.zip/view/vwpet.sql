CREATE view [dbo].[vwpet] as
Select p.pet_no, c.cust_no, c.cust_surname, p.pet_name, br.breed_no, br.breed_desc, s.spec_desc, pet_dob, pet_sex
from petadmin6..tblpet p
Join petadmin6..tblcustomer c on c.cust_no = p.pet_cust_no
Join petadmin6..tblbreed br on br.breed_no = p.pet_breed_no
Join petadmin6..tblspecies s on s.spec_no = p.pet_spec_no
