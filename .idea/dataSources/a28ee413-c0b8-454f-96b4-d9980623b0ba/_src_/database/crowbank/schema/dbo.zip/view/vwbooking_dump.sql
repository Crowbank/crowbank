CREATE view [dbo].[vwbooking_dump] as
select bk_no, bk_cust_no, convert(varchar(30), cast(bk_start_date as date), 120) bk_start_date, convert(varchar(30), cast(bk_end_date as date), 120) bk_end_date,
bk_start_datetime, bk_end_datetime, 
bk_start_time, bk_end_time, bk_gross_amt, bk_paid_amt, bk_amt_outstanding, case when bk_status = '' then 'P' else bk_status end bk_status,
bk_peak, bk_skip_confirm, bk_deluxe, convert(varchar(30), cast(bk_create_date as date), 120) bk_create_date
from vwbooking
