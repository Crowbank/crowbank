create view vwinvextra
as
Select ie_bk_no, ie_desc, ie_unit_price, ie_quantity from petadmin6..tblinvextra