CREATE function [dbo].[fnfixempty](@s as varchar(max)) returns varchar(max)
as
begin
	if @s = ''
		return NULL
	return @s
end
