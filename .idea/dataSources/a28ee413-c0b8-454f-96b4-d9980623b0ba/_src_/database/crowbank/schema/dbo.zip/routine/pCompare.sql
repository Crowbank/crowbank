CREATE Procedure pCompare (@start date, @end date)
as
declare @late_start date
declare @late_end date
declare @cutoff date
declare @current date
declare @last_year_revenue float
declare @last_year_count int
declare @last_year_by_cutoff_revenue float
declare @last_year_by_cutoff_count int
declare @this_year_revenue float
declare @this_year_count int

set @late_start = dateadd(year, 1, @start)
set @late_end = dateadd(year, 1, @end)
set @current = getdate()
set @cutoff = dateadd(year, -1, @current)

select @last_year_revenue = sum(rv_revenue), @last_year_count = sum(bi_c) from vwrevenue_by_create_date
where rv_date between @start and @end

select @last_year_by_cutoff_revenue = sum(rv_revenue), @last_year_by_cutoff_count = sum(bi_c) from vwrevenue_by_create_date
where rv_date between @start and @end and bk_create_date < @cutoff

select @this_year_revenue = sum(rv_revenue), @this_year_count = sum(bi_c) from vwrevenue_by_create_date
where rv_date between @late_start and @late_end

select 'This Year' Title, @this_year_revenue Revenue, @this_year_count Night_Count, 0 Revenue_Change, 0 Count_Change
union all
select 'Last Year Total', @last_year_revenue, @last_year_count, @this_year_revenue / @last_year_revenue - 1, (@this_year_count * 1.0) / @last_year_count - 1
union all
select 'Last Year by Cutoff', @last_year_by_cutoff_revenue, @last_year_by_cutoff_count, @this_year_revenue / @last_year_by_cutoff_revenue - 1, (@this_year_count * 1.0) / @last_year_by_cutoff_count - 1
