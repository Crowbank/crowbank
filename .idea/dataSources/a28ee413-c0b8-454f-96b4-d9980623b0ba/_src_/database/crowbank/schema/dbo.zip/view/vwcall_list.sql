CREATE view [dbo].[vwcall_list]
As
select bk_no, cust_no, cust_surname, cust_telno_home, cust_telno_mobile, cust_email, cust_addr1, cust_postcode, dbo.fnbk_pet_desc(bk_no) pets, bk_start_date, bk_end_date, bk_end_time, bk_gross_amt,
bk_create_date, isnull(sc_score, 0) sc_score, Case when IsNull(sc_score_good, 0) = 0 and IsNull(sc_Score_bad, 0) = 0 then 1 else 0 end first_timer, dr_date, dr_amount, min_c total_future_bookings, case when cust_notes like '%No deposit%' then 'No Deposit Required' else
case when pd_cust_no is null then
case when hist_bk_no is null then 'Deposit Required' else 'Confirmation Sent' end
else 'Deposit Previously Paid' end end deposit_required, kc_desc, cust_notes, bk_memo
from petadmin6..tblcustomer
join (select bk_cust_no min_cust_no, min(bk_start_date) min_bk_start_date, count(*) min_c from petadmin6..tblbooking where bk_status in ('', 'V') and bk_start_date >= Convert(date, GETDATE()) group by bk_cust_no) m on min_cust_no = cust_no
join petadmin6..tblbooking on bk_cust_no = cust_no and bk_start_date = min_bk_start_date
left join (
	select bk_cust_no sc_cust_no, sum(case when bk_status in ('', 'V') then 1 else -1 end) sc_score,
	sum(case when bk_status in ('', 'V') then 1 end) sc_score_good,
	sum(case when bk_status not in ('', 'V') then 1 end) sc_score_bad
	from petadmin6..tblbooking where bk_start_date < GETDATE() group by bk_cust_no
) sc on sc_cust_no = bk_cust_no
left join PA2..tbldepositrequest on dr_bk_no = bk_no
left join (select distinct bk_cust_no pd_cust_no from petadmin6..tblbooking join petadmin6..tblpayment on pay_bk_no = bk_no where bk_start_date > '20160101' and pay_date < bk_start_date) pd on pd_cust_no = cust_no
left join (select distinct hist_bk_no from petadmin6..tblhistory where hist_subject like 'Confirmed Booking%') h on hist_bk_no = bk_no
join vwkc_status on kc_bk_no = bk_no
where bk_status = '' and isnull(sc_score, 0) < 4 and bk_gross_amt <> 0
