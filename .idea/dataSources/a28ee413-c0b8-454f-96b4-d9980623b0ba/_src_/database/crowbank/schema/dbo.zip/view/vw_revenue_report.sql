CREATE view vw_revenue_report
as
select case when bk_quarter = 1 then bk_year - 1 else bk_year end [Financial Year],
bk_year [Calendar Year], case when bk_quarter in (1, 4) then 'Winter' else 'Summer' end Season,
'Q' + convert(varchar(1), bk_quarter) [Quarter],
spec_desc [Species], sum(pet_days) [Pet Days], srv_type [Service], sum(ii_net_amt) [Gross Revenue], sum(ii_net_amt) * 5 / 6.0 [Net Revenue]
from vw_revenue_daily
group by bk_year, bk_quarter, case when bk_quarter = 1 then bk_year - 1 else bk_year end, case when bk_quarter in (1, 4) then 'Winter' else 'Summer' end, spec_desc, srv_type
