create view vwservice as
select srv_no, srv_desc, srv_code from petadmin6..tblservice
