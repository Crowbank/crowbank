CREATE view [dbo].[vwrecentaudit]
As
select bk_no, aud_type, aud_action, aud_datetime, aud_bk_start_date, aud_bk_end_date, aud_amount, aud_nodeposit, bk_status, aud_date, aud_booking_count
from vwaudit
where aud_datetime > (select max(conf_time) from tblconfirm)
