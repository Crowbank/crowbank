CREATE view [dbo].[vwdepositrequest]
As
Select dr_no, dr_bk_no, dr_amount, dr_date, bk_cust_no dr_cust_no, Case when bk_start_date > GETDATE() and bk_status in ('', 'V') then 1 else 0 end dr_relevant
from tbldepositrequest
join petadmin6..tblbooking on bk_no = dr_bk_no
