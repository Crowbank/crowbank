create view vwrun as
select run_no, run_code, IsNull(spec_desc, '*') spec_desc, rt_desc
                from petadmin6..tblrun
                left join petadmin6..tblspecies on spec_no = run_spec_no
                left join petadmin6..tblruntype on rt_no = run_rt_no
