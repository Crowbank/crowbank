CREATE view [dbo].[vwrunoccupancy] as
select ro_bk_no, ro_run_no, ro_pet_no, ro_date, rt_no, rt_desc, spec_no, spec_desc, bk_status,
breed_no, breed_desc, billcat_no, billcat_desc,
case when ro_date = bk_start_date and ro_date = bk_end_date then 'D' else
	case when ro_date = bk_start_date then 'E' else
	case when ro_date = bk_end_date then 'M'
	else 'F' end end end ro_type
from petadmin6..tblrunoccupancy
join petadmin6..tblpet on pet_no = ro_pet_no
join petadmin6..tblspecies on spec_no = pet_spec_no
join petadmin6..tblbreed on breed_no = pet_breed_no
join petadmin6..tblbillcategory on billcat_no = breed_billcat_no
join petadmin6..tblbooking on bk_no = ro_bk_no
join petadmin6..tblrun on run_no = ro_run_no
join petadmin6..tblruntype on run_rt_no = rt_no
