create procedure pupdate_employee_wage1(@date date, @emp_no int, @rate float, @hours float, @kennel_cost money, @leave_hours float, @leave_cost money, @total money)
as
if exists (select * from tblemployeewage where ew_date = @date and ew_emp_no = @emp_no)
	update tblemployeewage set ew_rate = @rate, ew_hours = @hours, ew_kennel_cost =@kennel_cost, ew_leave_hours = @leave_hours,
	ew_leave_cost = @leave_cost, ew_gross =@total
	where ew_date = @date and ew_emp_no = @emp_no
else
	insert into tblemployeewage (ew_date, ew_emp_no, ew_rate, ew_hours, ew_kennel_cost, ew_leave_hours, ew_leave_cost,
	ew_gross) values (@date, @emp_no, @rate, @hours, @kennel_cost, @leave_hours, @leave_cost, @total)

