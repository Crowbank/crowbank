CREATE procedure [dbo].[padd_vacc] (@pet_no int)
As
Declare @path varchar(999)

Set @path = 'Z:\Kennels\Vaccination Cards\' + Convert(varchar(5), @pet_no) + '.pdf'

Delete from petadmin6..tblpetdocument where pd_pet_no = @pet_no

Insert into petadmin6..tblpetdocument (pd_pet_no, pd_desc, pd_path) values (@pet_no, 'Vaccination Card', @path)
