create view vwpetdocument as
select pd_pet_no, pd_desc, pd_path from petadmin6..tblpetdocument
