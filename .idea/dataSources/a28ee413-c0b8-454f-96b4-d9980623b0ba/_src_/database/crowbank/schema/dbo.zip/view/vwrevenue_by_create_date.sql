CREATE View [dbo].[vwrevenue_by_create_date]
As
select rv_date, bk_create_date, 5 / 6.0 * sum(rv_revenue) rv_revenue, sum(bi_c) bi_c from (
Select ro_date rv_date, bk_create_date, Sum(ii_rate) rv_revenue, count(*) bi_c
from petadmin6..tblrunoccupancy
Join petadmin6..tblbooking on bk_no = ro_bk_no
Join petadmin6..tblinvitem on ii_bk_no = bk_no and ii_pet_no = ro_pet_no
Join (Select bi_bk_no, count(*) bi_c from petadmin6..tblbookingitem group by bi_bk_no) bi on bi_bk_no = bk_no
Left Join petadmin6..tblholiday on h_date = ro_date
where ro_ignore <> 'Y' and bk_status not in ('C', 'N') and ii_peak = IsNull(h_state, '')
group by ro_date, bk_create_date) x
group by rv_date, bk_create_date
