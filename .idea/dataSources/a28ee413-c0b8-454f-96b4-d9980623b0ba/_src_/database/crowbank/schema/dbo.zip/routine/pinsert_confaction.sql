CREATE procedure [dbo].[pinsert_confaction] (@conf_no int, @bk_no int, @action varchar(1), @subject varchar(100), @filename varchar(999), @email varchar(100) = '')
As
Declare @cust_no int
Declare @cust_email varchar(100)
Declare @hist_no int

Select @cust_no = bk_cust_no from petadmin6..tblbooking where bk_no = @bk_no

Select @cust_email = cust_email from petadmin6..tblcustomer where cust_no = @cust_no

if @email <> ''
	Set @cust_email = @email

Insert into petadmin6..tblhistory (hist_cust_no, hist_bk_no, hist_date, hist_type, hist_report,
        hist_destination, hist_subject, hist_msg) values (@cust_no, @bk_no, GETDATE(), 'Email Client',
		'Conf-mail', @cust_email, @subject, @filename)

Select @hist_no = @@IDENTITY

IF @conf_no <> 0
	Insert into tblconfirmaction (ca_conf_no, ca_bk_no, ca_action, ca_hist_no) values
	(@conf_no, @bk_no, @action, @hist_no)
