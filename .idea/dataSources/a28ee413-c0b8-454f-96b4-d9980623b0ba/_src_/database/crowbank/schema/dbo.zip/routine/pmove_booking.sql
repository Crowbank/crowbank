CREATE Procedure [dbo].[pmove_booking] @bk_no int, @new_cust_no int
As
Declare @old_cust_no int

Select @old_cust_no = bk_cust_no from petadmin6..tblbooking where bk_no = @bk_no

Create table #pet_map (pet_name varchar(100), old_pet_no int, new_pet_no int)

Insert into #pet_map
Select p1.pet_name, p1.pet_no, p2.pet_no
from petadmin6..tblpet p1
join petadmin6..tblpet p2 on p1.pet_name = p2.pet_name
where p1.pet_cust_no = @old_cust_no and p2.pet_cust_no = @new_cust_no

update petadmin6..tblbooking set bk_cust_no = @new_cust_no where bk_no = @bk_no
update petadmin6..tblbookingitem set bi_pet_no = new_pet_no from #pet_map where bi_bk_no = @bk_no and bi_pet_no = old_pet_no
update petadmin6..tblrunoccupancy set ro_pet_no = new_pet_no from #pet_map where ro_bk_no = @bk_no and ro_pet_no = old_pet_no

update petadmin6..tblpayment set pay_cust_no = @new_cust_no where pay_bk_no = @bk_no
update petadmin6..tblhistory set hist_cust_no = @new_cust_no where hist_bk_no = @bk_no
update petadmin6..tblaudit set aud_cust_no = @new_cust_no where aud_key = @bk_no and aud_type = 'B'
update petadmin6..tblaudit set aud_cust_no = @new_cust_no where aud_key in (select pay_no from tblpayment where pay_bk_no = @bk_no) and aud_type = 'P'
