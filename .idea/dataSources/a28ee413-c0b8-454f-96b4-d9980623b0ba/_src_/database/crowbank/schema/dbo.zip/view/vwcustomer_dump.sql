CREATE view [dbo].[vwcustomer_dump] as
select cust_no,
	dbo.fnfixempty(cust_title) cust_title, dbo.fnfixempty(cust_surname) cust_surname, dbo.fnfixempty(cust_forename) cust_forename, cust_nodeposit, cust_deposit_requested,
dbo.fnfixempty(cust_addr1) cust_addr1, dbo.fnfixempty(cust_addr2) cust_addr2, dbo.fnfixempty(cust_addr3) cust_addr3, dbo.fnfixempty(cust_postcode) cust_postcode,
dbo.fnfixempty(cust_telno_home) cust_telno_home, dbo.fnfixempty(cust_email) cust_email, dbo.fnfixempty(cust_telno_mobile) cust_telno_mobile, dbo.fnfixempty(cust_telno_mobile2) cust_telno_mobile2
from vwcustomer
