CREATE View [dbo].[vwbookingitem] as
Select b.bk_no, p.pet_no, b.bk_status, i.bi_pet_no, b.bk_start_date, b.bk_end_date, c.cust_surname, p.pet_name, br.breed_desc, s.spec_desc
from petadmin6..tblbooking b
Join petadmin6..tblcustomer c on c.cust_no = b.bk_cust_no
Join petadmin6..tblbookingitem i on i.bi_bk_no = b.bk_no
Join petadmin6..tblpet p on p.pet_no = i.bi_pet_no
Join petadmin6..tblbreed br on br.breed_no = p.pet_breed_no
Join petadmin6..tblspecies s on s.spec_no = p.pet_spec_no
