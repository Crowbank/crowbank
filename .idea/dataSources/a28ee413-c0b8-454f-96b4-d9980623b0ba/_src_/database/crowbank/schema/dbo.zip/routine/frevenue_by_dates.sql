CREATE Function [dbo].[frevenue_by_dates] (@StartDate as date, @EndDate as date) Returns @B Table (date date, days_to_go int, revenue money, pet_count int)
As
Begin
	Declare @start int
	Select @Start = datenum from date where date = @EndDate

	Insert into @b(date, days_to_go, revenue, pet_count)
	Select date, @start - datenum days_to_go, sum(rv_revenue) rv_revenue, sum(bi_c) bi_c
	from date left join vwrevenue_by_create_date on date >= bk_create_date
	and rv_date between @StartDate and @EndDate
	where date <= @EndDate
	group by date, datenum
	Return
End
