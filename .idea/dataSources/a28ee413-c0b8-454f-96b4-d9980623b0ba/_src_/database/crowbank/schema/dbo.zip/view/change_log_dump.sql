CREATE view [dbo].[change_log_dump] as
select change_id, change_timestamp, change_type, change_table, IsNull(change_pk, 0) change_pk, IsNull(change_pk2, 0) change_pk2, change_sql
from change_log
where change_sql is not null and isnull(dumped, 0) = 0
