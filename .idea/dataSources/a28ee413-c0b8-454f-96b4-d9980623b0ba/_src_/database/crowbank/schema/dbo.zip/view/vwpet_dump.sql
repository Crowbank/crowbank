CREATE view [dbo].[vwpet_dump] as
select pet_no, pet_cust_no, pet_name, spec_desc pet_spec, pet_breed_no, pet_dob, pet_sex, pet_vet_no, replace(cast(pet_notes as nvarchar(max)), char(13) + char(10), '\\') pet_notes
from petadmin6..tblpet
join petadmin6..tblspecies on spec_no = pet_spec_no
