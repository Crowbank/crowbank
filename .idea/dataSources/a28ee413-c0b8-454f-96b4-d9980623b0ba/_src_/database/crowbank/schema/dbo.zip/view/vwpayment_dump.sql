create view [dbo].[vwpayment_dump] as
select pay_no, pay_bk_no, pay_cust_no, pay_date, pay_amount, pay_type
from petadmin6..tblpayment
