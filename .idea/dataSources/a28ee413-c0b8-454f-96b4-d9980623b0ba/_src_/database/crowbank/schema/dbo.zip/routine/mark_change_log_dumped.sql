create procedure [dbo].[mark_change_log_dumped]
as
begin 
update change_log set dumped = 1
end
