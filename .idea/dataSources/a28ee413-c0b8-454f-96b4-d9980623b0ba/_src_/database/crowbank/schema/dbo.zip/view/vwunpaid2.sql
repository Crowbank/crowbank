CREATE View [dbo].[vwunpaid2] As
select date, sum(dog_unpaid) * 5 / 6.0 dog_unpaid, sum(cat_unpaid) * 5 / 6.0 cat_unpaid, sum(total_unpaid) * 5 / 6.0 total_unpaid,
sum(total_unpaid) / 6.0 unpaid_vat
from (
Select date, si_srv_no, bk_no, si_peak, sum(case when pet_spec_no = 1 then si_units end) * ii_rate dog_unpaid,
sum(case when pet_spec_no = 2 then si_units end) * ii_rate cat_unpaid,
sum(si_units) * ii_rate total_unpaid
from tbldate
join petadmin6..tblserviceitem on si_date <= date
join petadmin6..tblbooking on bk_no = si_bk_no and bk_end_date > date and bk_status in ('', 'V')
join petadmin6..tblpet on pet_no = si_pet_no
join petadmin6..tblinvitem on ii_bk_no = bk_no and ii_pet_no = pet_no and ii_srv_no = si_srv_no and ii_peak = si_peak
group by date, si_srv_no, bk_no, si_peak, ii_rate) x
group by date
