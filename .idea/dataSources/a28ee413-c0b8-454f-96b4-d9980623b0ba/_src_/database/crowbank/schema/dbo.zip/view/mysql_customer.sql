create view [dbo].[mysql_customer] as
select cust_no, cust_title, cust_surname, cust_forename, cust_addr1, cust_addr2, cust_addr3, cust_postcode, cust_telno_home, cust_telno_mobile,
cust_telno_mobile2, cust_email
from petadmin6..tblcustomer
