Create View [dbo].[vwbreed] as
Select breed_no, breed_desc, spec_desc, billcat_no, billcat_desc
from petadmin6..tblbreed
join petadmin6..tblspecies on spec_no = breed_spec_no
join petadmin6..tblbillcategory on breed_billcat_no = billcat_no
