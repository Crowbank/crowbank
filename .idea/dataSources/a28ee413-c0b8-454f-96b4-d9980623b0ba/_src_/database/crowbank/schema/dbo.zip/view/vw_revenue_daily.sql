CREATE view vw_revenue_daily
as
select year(si_date) bk_year, datepart(quarter, si_date) bk_quarter, si_date, spec_desc, sum(si_units) pet_days,
case when srv_code in ('BOARD', 'BOARD2', 'BOARD3') then 'BOARD' else
case when srv_code in ('DELUXE', 'DELUXE2', 'DLX-DISC', 'DLX-DIS2') then 'DELUXE' else
case when srv_code in ('HOME', 'HOME2') then 'HOME' else srv_code end end end srv_type,
sum(ii_rate * si_units * (1 - case when bk_disc_type = 'P' then bk_disc_value / 100.0 else bk_disc_value / bk_gross_amt end)) ii_net_amt
from petadmin6..tblbooking
join petadmin6..tblinvitem on ii_bk_no = bk_no
join petadmin6..tblserviceitem on si_bk_no = bk_no and si_srv_no = ii_srv_no and si_peak = ii_peak and si_pet_no = ii_pet_no
join petadmin6..tblservice on srv_no = si_srv_no
join petadmin6..tblpet on pet_no = ii_pet_no
join petadmin6..tblspecies on spec_no = pet_spec_no
where bk_status in ('', 'V') and bk_gross_amt <> 0 and srv_code not in ('PICKUP', 'DROPOFF', 'DAYCARE', 'DAYCARE2', 'DIAB', 'BATH')
group by si_date, spec_desc,
case when srv_code in ('BOARD', 'BOARD2', 'BOARD3') then 'BOARD' else
case when srv_code in ('DELUXE', 'DELUXE2', 'DLX-DISC', 'DLX-DIS2') then 'DELUXE' else
case when srv_code in ('HOME', 'HOME2') then 'HOME' else srv_code end end end
