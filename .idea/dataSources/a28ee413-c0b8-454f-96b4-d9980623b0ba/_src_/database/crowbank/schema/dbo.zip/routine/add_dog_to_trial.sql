create procedure [dbo].[add_dog_to_trial](@bk_no int, @pet_no int)
As
Declare @date date
Declare @run_no int

Select @date = bk_start_date from PA..tblbooking where bk_no = @bk_no

Insert into petadmin6..tblbookingitem (bi_bk_no, bi_pet_no, bi_checkin_date, bi_checkin_time, bi_est_checkin_time, bi_checkout_date, bi_checkout_time, bi_est_checkout_time,
bi_medication, bi_groom, bi_in_season, bi_init_in, bi_init_out, bi_heating, bi_rs_no, bi_comments, bi_pickup_time, bi_dropoff_time)
values (@bk_no, @pet_no, @date, '', '14:00', @date, '', '17:00', 'N', '', '', '', '', 'N', -1, '', '1900-01-01 00:00:00.000', '1900-01-01 00:00:00.000')

If Exists (Select * from petadmin6..tblrunoccupancy where ro_bk_no = @bk_no)
	Select @run_no = max(ro_run_no) from petadmin6..tblrunoccupancy where ro_bk_no = @bk_no
Else
	Select @run_no = min(run_no) from petadmin6..tblrun
	where run_spec_no = 1 and run_inactive = '' and run_rs_no = 1
	and run_no not in (select distinct ro_run_no from petadmin6..tblrunoccupancy where ro_date = @date)

If @run_no is not null
	Insert into petadmin6..tblrunoccupancy (ro_run_no, ro_pet_no, ro_date, ro_bk_no, ro_isolated, ro_ignore)
	values (@run_no, @pet_no, @date, @bk_no, '', '')


