CREATE view [dbo].[vwprepaid] as
select date, sum(pay_amount * t_dog_amt / t_net_amt) * 5 / 6.0 dog_prepaid_amount,
sum(pay_amount * t_cat_amt / t_net_amt) * 5 / 6.0 cat_prepaid_amount,
sum(pay_amount) * 5 / 6.0 prepaid_amount, sum(pay_amount) / 6.0 prepaid_vat
from petadmin6..tblpayment 
join petadmin6..tblbooking on pay_bk_no = bk_no
join (select ii_bk_no t_bk_no, sum(case when pet_spec_no = 1 then ii_net_amt end) t_dog_amt,
sum(case when pet_spec_no = 2 then ii_net_amt end) t_cat_amt,
sum(ii_net_amt) t_net_amt
from petadmin6..tblinvitem
join petadmin6..tblpet on pet_no = ii_pet_no
group by ii_bk_no) t on t_bk_no = bk_no
join tbldate on 1=1
where bk_end_date > date and pay_date <= date and t_net_amt <> 0
group by date
