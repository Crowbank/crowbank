create procedure pupdate_employee_wage2 (@date date, @emp_no int, @reported money, @studentloan money, @paye money, @nic money, @net money)
as
update tblemployeewage set ew_reported = @reported, ew_studentloan = @studentloan, ew_paye = @paye, ew_nic = @nic, ew_net = @net
where ew_emp_no = @emp_no and ew_date = @date
