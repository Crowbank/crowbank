CREATE View [dbo].[vwpayment] as
with payment as (
select pay_bk_no, pay_date, cust_surname, sum(pay_amount) pay_amount, pay_type
from petadmin6..tblpayment
join petadmin6..tblbooking on bk_no = pay_bk_no
join petadmin6..tblcustomer on cust_no = bk_cust_no
group by pay_bk_no, pay_date, pay_type, cust_surname),
total_payment as (
select pay_bk_no tp_bk_no, sum(pay_amount) total_pay_amount
from petadmin6..tblpayment group by pay_bk_no having sum(pay_amount) > 0),
invoiced as (
select ii_bk_no inv_bk_no, spec_desc spec, sum(ii_net_amt) inv_amount
from petadmin6..tblinvitem
join petadmin6..tblpet on pet_no = ii_pet_no
join petadmin6..tblspecies on spec_no = pet_spec_no
group by ii_bk_no, spec_desc
union all
select ie_bk_no, ie_desc, sum(ie_total)
from petadmin6..tblinvextra group by ie_bk_no, ie_desc),
total_invoiced as (
select inv_bk_no ti_bk_no, sum(inv_amount) ti_amount from invoiced group by inv_bk_no having sum(inv_amount) <> 0)
select pay_bk_no bk_no, pay_date, cust_surname, spec,
sum(case when pay_type like '%Cash%' then pay_amount * inv_amount / ti_amount end) cash,
sum(case when pay_type like '%Debit Card%' then pay_amount * inv_amount / ti_amount end) dcard,
sum(case when pay_type like '%Credit Card%' then pay_amount * inv_amount / ti_amount end) ccard,
sum(case when pay_type not like '%Card%' and pay_type not like '%Cash%' then pay_amount * inv_amount / ti_amount end) other
from payment
join invoiced on inv_bk_no = pay_bk_no
join total_invoiced on ti_bk_no = pay_bk_no
group by pay_bk_no, pay_date, cust_surname, spec
