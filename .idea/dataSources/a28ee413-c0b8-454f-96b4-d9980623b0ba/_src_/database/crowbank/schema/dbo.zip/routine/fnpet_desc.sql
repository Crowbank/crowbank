CREATE Function [dbo].[fnpet_desc](@cust_no int) Returns varchar(255)
As
Begin
Declare @count int
Declare @min_pet_no int
Declare @pet_names varchar(255)
Declare @pet_desc varchar(100)

Select @count = count(*) from petadmin6..tblpet where pet_cust_no = @cust_no

If @count = 0
	Return ''

If @count = 1
Begin
	Select @pet_names = pet_desc from vwpetdesc where pet_cust_no = @cust_no
	Return @pet_names
End

Select @min_pet_no = Min(pet_no) from petadmin6..tblpet where pet_cust_no = @cust_no

Declare pet_cursor Cursor for
Select pet_desc from vwpetdesc where pet_cust_no = @cust_no and pet_no > @min_pet_no

Select @pet_names = pet_desc from vwpetdesc where pet_no = @min_pet_no

Open pet_cursor
FETCH NEXT From pet_cursor into @pet_desc

While @@FETCH_STATUS  = 0
Begin
	Set @pet_names = @pet_names + ', ' + @pet_desc
	FETCH NEXT From pet_cursor into @pet_desc
End

Close pet_cursor
Deallocate pet_cursor

Return @pet_names
End
