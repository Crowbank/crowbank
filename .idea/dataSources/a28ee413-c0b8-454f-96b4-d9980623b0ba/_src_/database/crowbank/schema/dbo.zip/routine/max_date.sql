create function max_date (@date1 date, @date2 date) returns date
as
begin
if @date1 > @date2
	return @date1

return @date2
end
