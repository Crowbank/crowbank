CREATE view vw_wage_report as
select [Year], [Month], kennel_cost [Kennel Cost], hours [Work Hours],
sum(case when [Species] = 'Dog' then [Pet Days] else 0 end) [Dog Days],
sum(case when [Species] = 'Cat' then [Pet Days] else 0 end) [Cat Days],
sum(case when [Species] = 'Dog' then [Turnover] else 0 end) [Dog Turnover],
sum(case when [Species] = 'Cat' then [Turnover] else 0 end) [Cat Turnover], [Revenue] from (
select year(eff_date) [Year], month(eff_date) [Month], spec_desc [Species], sum(pet_days) [Pet Days], sum(ii_net_amt) [Revenue],
sum(turnover) [Turnover] from (
select dateadd(day, case when day(si_date) > 25 then 7 else 0 end, si_date) eff_date, spec_desc, pet_days, ii_net_amt, isnull(c, 0) turnover
from vw_revenue_daily
left join (
	select 'in' direction, 'Dog' species, bk_start_date check_date, count(*) c from vwbooking where has_dogs = 1 and bk_status in ('', 'V') group by bk_start_date
union all
	select 'in', 'Cat', bk_start_date, count(*) from vwbooking where has_cats = 1 and bk_status in ('', 'V') group by bk_start_date
union all
	select 'out', 'Dog', bk_end_date, count(*) from vwbooking where has_dogs = 1 and bk_status in ('', 'V') group by bk_end_date
union all
	select 'out', 'Cat', bk_end_date, count(*) from vwbooking where has_cats = 1 and bk_status in ('', 'V') group by bk_end_date) c on check_date = si_date and species = spec_desc
left join (select bk_end_date, count(*) co from vwbooking where bk_status in ('', 'V') group by bk_end_date) e on bk_end_date = si_date) x
group by year(eff_date), month(eff_date), spec_desc) k
join (select year(ew_date) y, month(ew_date) m, sum(ew_gross) kennel_cost, sum(ew_hours) hours from tblemployeewage group by year(ew_date), month(ew_date)) w
on w.y = [Year] and w.m = [Month]
group by [Year], [Month], kennel_cost, hours, [Revenue]
