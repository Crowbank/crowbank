CREATE View [dbo].[vwpetdesc]
As
Select pet_no, pet_cust_no, pet_name, spec_desc, bs_desc, pet_name + ' (' + Case when spec_desc = 'Cat' then 'Cat' else bs_desc end + ')' pet_desc
from petadmin6..tblpet
Join petadmin6..tblspecies on pet_spec_no = spec_no
Join tblbreedshortname on bs_breed_no = pet_breed_no
