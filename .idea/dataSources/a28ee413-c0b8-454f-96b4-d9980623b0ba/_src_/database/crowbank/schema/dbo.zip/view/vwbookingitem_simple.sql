create view vwbookingitem_simple as
select bi_bk_no, bi_pet_no from petadmin6..tblbookingitem
