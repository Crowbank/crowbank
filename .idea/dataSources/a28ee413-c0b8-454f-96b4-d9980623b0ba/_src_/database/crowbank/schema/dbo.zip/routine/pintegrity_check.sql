CREATE procedure pintegrity_check
as
if exists (select * from petadmin6..tblbookingitem where bi_bk_no not in (select bk_no from petadmin6..tblbooking))
begin
	select 'orphan bookingitem'
	select * from petadmin6..tblbookingitem where bi_bk_no not in (select bk_no from petadmin6..tblbooking)
end
if exists (select * from petadmin6..tblinvitem where ii_bk_no not in (select bk_no from petadmin6..tblbooking))
begin
	select 'orphan invitem'
	select * from petadmin6..tblinvitem where ii_bk_no not in (select bk_no from petadmin6..tblbooking)
end
if exists (select * from petadmin6..tblbooking where bk_no not in (select bi_bk_no from petadmin6..tblbookingitem))
begin
	select 'bookings without items'
	select * from petadmin6..tblbooking where bk_no not in (select bi_bk_no from petadmin6..tblbookingitem)
end
if exists (select * from petadmin6..tblbookingitem join petadmin6..tblbooking on bk_no = bi_bk_no join petadmin6..tblpet on pet_no = bi_pet_no where bi_checkin_date <> bk_start_date
or bi_checkout_date <> bk_end_date or pet_cust_no <> bk_cust_no)
begin
	select 'booking/item mismatch'
	select bk_no, bk_start_date, cust_surname, pets, bi_checkin_date, bk_end_date, bi_checkout_date from petadmin6..tblbookingitem join vwbooking on bk_no = bi_bk_no join petadmin6..tblpet on pet_no = bi_pet_no where bi_checkin_date <> bk_start_date
or bi_checkout_date <> bk_end_date or pet_cust_no <> bk_cust_no
end
