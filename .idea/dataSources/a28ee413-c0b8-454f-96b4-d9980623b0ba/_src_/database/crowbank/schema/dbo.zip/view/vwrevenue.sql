CREATE View [dbo].[vwrevenue]
As
Select ro_date rv_date, Sum(ii_rate) rv_revenue 
from petadmin6..tblrunoccupancy
Join petadmin6..tblbooking on bk_no = ro_bk_no
Join petadmin6..tblinvitem on ii_bk_no = bk_no and ii_pet_no = ro_pet_no
Left Join petadmin6..tblholiday on h_date = ro_date
where ro_ignore <> 'Y' and bk_status not in ('C', 'N') and ii_peak = IsNull(h_state, '')
group by ro_date
