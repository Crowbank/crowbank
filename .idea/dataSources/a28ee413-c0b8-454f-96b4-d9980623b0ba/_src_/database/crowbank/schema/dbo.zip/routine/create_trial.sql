CREATE procedure [dbo].[create_trial](@cust_no as int, @date as date)
As
Declare @bk_no int
Declare @current_date date
Declare @current_time varchar(5)

select @current_time = Convert(varchar(5), GETDATE(), 14)
select @current_Date = Convert(date, GETDATE())

Insert into petadmin6..tblbooking (bk_cust_no, bk_start_date, bk_end_date, bk_start_time, bk_end_time,
bk_gross_amt, bk_paid_amt, bk_vat_amt, bk_net_amt, bk_vat_percentage, bk_amt_outstanding, bk_extra_net_amt, bk_disc_value,
bk_disc_type, bk_disc_total, bk_paytype, bk_payref, bk_notes, bk_extra_vat_amt, bk_inv_date,

bk_disc_vat, bk_vat2_amt, bk_extra_vat2_amt, bk_disc_vat2, bk_status, bk_create_date, bk_memo, bk_print_ack, bk_print_conf, bk_print_contract, bk_print_inv,
bk_memo_flag_in, bk_memo_flag_out, bk_archive, bk_rate_seq, bk_pickup_no, bk_dropoff_no, bk_type, bk_tr_no, bk_ti_no,
bk_club_no, bk_ev_no, bk_ev_places, bk_new, bk_recur, bk_diary_count, bk_run_lock, bk_pickup_status, bk_dropoff_status)
values (@cust_no, @date, @date, '14:00', '17:00', 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 'P', 0.0, '', '', '', 0.0, @date,
0.0, 0.0, 0.0, 0.0, '', GETDATE(), '', '', '', '', '', '', '', '', 0, -1, -1, 'B', 0, 0, 0, 0, 0, '', 0, 0, '', '', '')

Select @bk_no = @@IDENTITY

update petadmin6..tblbooking set bk_inv_no = @bk_no where bk_no = @bk_no

Declare @surname varchar(100)
select @surname = cust_surname from PA..tblcustomer where cust_no = @cust_no

Insert into petadmin6..tblaudit (aud_init, aud_key, aud_type, aud_action, aud_date, aud_time, aud_cust_no, aud_cust_surname, aud_bk_start_date, aud_bk_end_date, aud_amount)
values ('', @bk_no, 'B', 'A', @current_date, @current_time, @cust_no, @surname, @date, @date, 0.0)

Select @bk_no
