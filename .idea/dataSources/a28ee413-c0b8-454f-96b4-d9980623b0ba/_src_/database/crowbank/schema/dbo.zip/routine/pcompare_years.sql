CREATE Procedure [dbo].[pcompare_years] (@StartDate as date, @EndDate as date, @Offset as Integer)
As
Declare @OffsetStart date
Declare @OffsetEnd date

Set @OffsetStart = DATEADD(year, @Offset, @StartDate)
Set @OffsetEnd = DATEADD(year, @Offset, @EndDate)

Select d1.days_to_go, d2.date, IsNull(d1.revenue, 0) early_revenue, IsNull(d2.revenue, 0) late_revenue,
Case when IsNull(d1.revenue, 0) = 0 then NULL else IsNull(d2.revenue, 0) / IsNull(d1.revenue, 0) - 1 end revenue_change,
IsNull(d1.pet_count, 0) early_pet_count, IsNull(d2.pet_count, 0) late_pet_count,
case when IsNull(d1.pet_count, 0) = 0 then NULL else 1.0 * IsNull(d2.pet_count, 0) / IsNull(d1.pet_count, 0) - 1 end pet_count_charge
from dbo.frevenue_by_dates(@StartDate, @EndDate) d1
join dbo.frevenue_by_dates(@OffsetStart, @OffsetEnd) d2 on d1.days_to_go = d2.days_to_go
where d1.revenue is not null or d2.revenue is not null
order by d1.days_to_go desc
