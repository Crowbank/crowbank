CREATE view vwhistory as
select hist_bk_no, hist_date, hist_report, hist_type, hist_destination, hist_subject from petadmin6..tblhistory
