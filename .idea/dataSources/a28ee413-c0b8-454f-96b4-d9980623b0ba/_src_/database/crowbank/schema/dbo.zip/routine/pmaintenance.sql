CREATE Procedure [dbo].[pmaintenance] As
update tbldepositrequest set dr_paid_date = pay_date
from petadmin6..tblpayment
join petadmin6..tblbooking on pay_bk_no = bk_no
where dr_bk_no = pay_bk_no and dr_amount = pay_amount and pay_date < bk_start_date
and dr_paid_date is null

update petadmin6..tblpayment set pay_Type = 'Debit Card' where pay_type = ' Debit Card'
