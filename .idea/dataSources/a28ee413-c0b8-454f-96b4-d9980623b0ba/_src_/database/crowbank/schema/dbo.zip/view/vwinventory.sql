CREATE View [dbo].[vwinventory] as
With run_count as (Select ro_run_no rc_run_no, ro_date rc_date, ro_bk_no rc_bk_no, count(*) rc_n
From petadmin6..tblrunoccupancy 
-- where ro_run_no <> -1
group by ro_run_no, ro_date, ro_bk_no),
run_occupant as (Select bk_no, spec_desc, run_no, ro_date, pet_no, cust_surname, pet_name, breed_desc, bk_start_date, bk_end_date, run_code,
Case when bk_start_date = ro_date then
	Case when bk_end_date = ro_date then 'Day' else 'In' end
else Case when bk_end_date = ro_date then 'Out' else '' end end in_out,
Case when run_no = -1 then '*' else '' end allocated
from petadmin6..tblrunoccupancy
Join petadmin6..tblpet on pet_no = ro_pet_no
Join petadmin6..tblspecies on pet_spec_no = spec_no
Join petadmin6..tblbreed on breed_no = pet_breed_no
Join petadmin6..tblcustomer on cust_no = pet_cust_no
Join petadmin6..tblbooking on bk_no = ro_bk_no
Join petadmin6..tblrun on run_no = ro_run_no
Where bk_status in ('', 'V'))
Select top 1000000 bk_no, run_code, date, spec, surname, pet_count, pet_no_1, pet1, breed1, pet_no_2, pet2, breed2, pet_no_3, pet3, breed3,
start_date, end_date, in_out, allocated from (
Select bk_no, run_code, ro_date date, spec_desc spec, cust_surname surname, 1 pet_count, pet_no pet_no_1, pet_name pet1, breed_desc breed1,
NULL pet_no_2, NULL pet2, NULL breed2, NULL pet_no_3, NULL pet3, NULL breed3, bk_start_date start_date, bk_end_date end_date, in_out, allocated
from run_occupant
Join run_count on rc_date = ro_date and rc_run_no = run_no and rc_n = 1 and rc_bk_no = bk_no
Union All
Select ro1.bk_no, ro1.run_code, ro1.ro_date, ro1.spec_desc, ro1.cust_surname, 2, ro1.pet_no, ro1.pet_name, ro1.breed_desc,
ro2.pet_no, ro2.pet_name, ro2.breed_desc, NULL, NULL, NULL, ro1.bk_start_date,
ro1.bk_end_date, ro1.in_out, ro1.allocated
from run_occupant ro1
Join run_occupant ro2 on ro1.ro_date = ro2.ro_date and ro1.run_no = ro2.run_no and ro1.bk_no = ro2.bk_no and ro1.pet_no < ro2.pet_no
Join run_count rc on rc.rc_date = ro1.ro_date and rc.rc_run_no = ro1.run_no and rc_n = 2 and rc_bk_no = ro1.bk_no
Union All
Select ro1.bk_no, ro1.run_code, ro1.ro_date, ro1.spec_desc, ro1.cust_surname, 3, ro1.pet_no, ro1.pet_name, ro1.breed_desc,
ro2.pet_no, ro2.pet_name, ro2.breed_desc, ro3.pet_no, ro3.pet_name, ro3.breed_desc, ro1.bk_start_date, ro1.bk_end_date, ro1.in_out, ro1.allocated
from run_occupant ro1
Join run_occupant ro2 on ro1.ro_date = ro2.ro_date and ro1.run_no = ro2.run_no and ro1.pet_no < ro2.pet_no and ro1.bk_no = ro2.bk_no
Join run_occupant ro3 on ro1.ro_date = ro3.ro_date and ro1.run_no = ro3.run_no and ro2.pet_no < ro3.pet_no and ro1.bk_no = ro3.bk_no
Join run_count rc on rc.rc_date = ro1.ro_date and rc.rc_run_no = ro1.run_no and rc_n = 3 and rc_bk_no = ro1.bk_no) x
Order by start_date, end_date
