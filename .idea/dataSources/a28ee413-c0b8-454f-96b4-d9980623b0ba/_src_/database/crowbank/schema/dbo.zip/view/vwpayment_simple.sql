create view vwpayment_simple as
Select pay_bk_no, pay_date, pay_amount, LTRIM(pay_type) pay_type from petadmin6..tblpayment
