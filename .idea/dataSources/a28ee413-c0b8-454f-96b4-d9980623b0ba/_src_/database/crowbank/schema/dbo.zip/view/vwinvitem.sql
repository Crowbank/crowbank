create view vwinvitem as
Select ii_bk_no, ii_pet_no, ii_srv_no, ii_quantity, ii_rate from petadmin6..tblinvitem
