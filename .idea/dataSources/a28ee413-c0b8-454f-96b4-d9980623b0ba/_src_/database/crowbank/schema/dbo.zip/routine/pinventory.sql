create procedure [dbo].[pinventory] (@date date)
as
select bk_no, cust_no, cust_surname, bk_start_date, bk_start_time, bk_end_date, bk_end_time, pet_name, breed_desc, run_code, rt_desc, c-1 previous_stays, bk_status, bk_paid_amt
from petadmin6..tblbooking
join petadmin6..tblbookingitem on bi_bk_no = bk_no
join petadmin6..tblpet on pet_no = bi_pet_no
join petadmin6..tblcustomer on cust_no = bk_cust_no
join petadmin6..tblbreed on breed_no = pet_breed_no
join (select bi_pet_no c_pet_no, count(*) c from petadmin6..tblbookingitem join petadmin6..tblbooking on bk_no = bi_bk_no and bk_status in ('', 'V') group by bi_pet_no) c on c_pet_no = pet_no
left join petadmin6..tblrunoccupancy on ro_bk_no = bk_no and ro_pet_no = pet_no and ro_date = @date
left join petadmin6..tblrun on run_no = ro_run_no
left join petadmin6..tblruntype on rt_no = run_rt_no
where bk_status in ('', 'V')
and pet_spec_no = 1
and bk_start_date <= @date
and bk_end_date > @date
order by rt_desc, bk_no
