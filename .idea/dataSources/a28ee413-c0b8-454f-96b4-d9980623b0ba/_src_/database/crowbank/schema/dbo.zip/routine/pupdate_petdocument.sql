create procedure pupdate_petdocument (@pet_no int, @pd_path varchar(999))
as
update petadmin6..tblpetdocument set pd_path = @pd_path where pd_pet_no = @pet_no
